# BookNet — Read · Explore · Grow

BookNet is a modern, responsive web application for discovering books, managing your personal reading library, tracking page progress, writing reviews, and connecting with a community of readers.

Built with **React**, **TypeScript**, **Tailwind CSS**, and **Vite**, and integrated with the **Open Library API** and legitimate public-domain literature sources.

---

## Quick Start (Local Development)

### 1. Prerequisites
- [Node.js](https://nodejs.org/) version 18.0 or newer
- `npm` (comes with Node.js)

### 2. Install Dependencies
```bash
npm install
```

### 3. Run Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 4. Run Unit Tests
```bash
npm run test
```

### 5. Build for Production
```bash
npm run build
```
The production bundle will be generated in the `dist/` directory.

---

## Deploying to Cloudflare Pages

### Step 1: Push Code to GitHub
1. Unzip the project files into a folder on your computer.
2. Initialize a Git repository and commit the files:
   ```bash
   git init
   git add .
   git commit -m "Initial commit of BookNet"
   ```
3. Create a new repository on [GitHub](https://github.com/new).
4. Push your local repository to GitHub:
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
   git branch -M main
   git push -u origin main
   ```

### Step 2: Connect to Cloudflare Pages
1. Log in to the [Cloudflare Dashboard](https://dash.cloudflare.com/).
2. In the left sidebar, navigate to **Workers & Pages** > **Create application** > **Pages** tab.
3. Select **Connect to Git** and choose the GitHub repository you just created.
4. Set the build configuration:
   - **Framework preset**: `Vite` (or `None`)
   - **Build command**: `npm run build`
   - **Build output directory**: `dist`
   - **Root directory**: `/` (leave blank or default)
5. Under **Environment variables**, set (optional if using Node 18+):
   - `NODE_VERSION` = `20`
6. Click **Save and Deploy**.

Cloudflare Pages will build the site in seconds and assign you a free `*.pages.dev` subdomain with instant global CDN distribution, HTTPS, and edge caching!

---

## Features
- **Book Discovery**: Search by title, author, or ISBN via live Open Library API.
- **Reading Progress Tracker**: Track page count, percentage, and personal notes.
- **Personal Library**: Shelves for *Want to Read*, *Currently Reading*, and *Finished*.
- **Reading Dashboard & Streaks**: Weekly page bar chart, annual goal pacing, and achievements.
- **Community Forum & Reviews**: Discussions, replies, rating breakdowns, and reading challenges.
- **Data Portability**: Full JSON export and restore in Settings.

---

## License
MIT License.
