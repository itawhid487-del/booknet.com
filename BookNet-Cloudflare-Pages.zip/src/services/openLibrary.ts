import { Book } from '../types/index';
import { INITIAL_BOOKS } from './booksData';

export interface OpenLibraryDoc {
  key: string;
  title: string;
  author_name?: string[];
  first_publish_year?: number;
  cover_i?: number;
  isbn?: string[];
  language?: string[];
  subject?: string[];
  publisher?: string[];
  number_of_pages_median?: number;
  ratings_average?: number;
  ratings_count?: number;
}

/**
 * Searches Open Library with fallback to local curated catalog
 */
export async function searchOpenLibrary(
  query: string,
  category: string = 'all',
  page: number = 1
): Promise<{ books: Book[]; total: number; source: 'open_library' | 'local' }> {
  const trimmed = query.trim();

  // If query is empty and category is all, return initial books
  if (!trimmed && (category === 'all' || !category)) {
    return {
      books: INITIAL_BOOKS,
      total: INITIAL_BOOKS.length,
      source: 'local',
    };
  }

  // Filter local catalog first
  const localMatches = INITIAL_BOOKS.filter((b) => {
    const matchesCategory =
      category === 'all' || b.category.toLowerCase() === category.toLowerCase();
    const matchesQuery =
      !trimmed ||
      b.title.toLowerCase().includes(trimmed.toLowerCase()) ||
      b.author.toLowerCase().includes(trimmed.toLowerCase()) ||
      (b.isbn && b.isbn.includes(trimmed));
    return matchesCategory && matchesQuery;
  });

  // If no query string, filter by genre locally
  if (!trimmed && category !== 'all') {
    return {
      books: localMatches,
      total: localMatches.length,
      source: 'local',
    };
  }

  // Attempt live Open Library Search API
  try {
    const params = new URLSearchParams();
    params.set('q', trimmed);
    if (category !== 'all') {
      params.set('subject', category.toLowerCase());
    }
    params.set('limit', '20');
    params.set('page', String(page));
    params.set('fields', 'key,title,author_name,first_publish_year,cover_i,isbn,language,subject,publisher,number_of_pages_median,ratings_average,ratings_count');

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000); // 6s timeout

    const res = await fetch(`https://openlibrary.org/search.json?${params.toString()}`, {
      signal: controller.signal,
      headers: {
        'Accept': 'application/json',
      },
    });
    clearTimeout(timeoutId);

    if (!res.ok) {
      throw new Error(`Open Library returned status ${res.status}`);
    }

    const data = await res.json();
    const docs: OpenLibraryDoc[] = data.docs || [];

    const mappedBooks: Book[] = docs.map((doc) => {
      const id = doc.key.replace('/works/', '');
      const coverUrl = doc.cover_i
        ? `https://covers.openlibrary.org/b/id/${doc.cover_i}-M.jpg`
        : 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=600';
      
      const author = doc.author_name ? doc.author_name.join(', ') : 'Unknown Author';
      const isbn = doc.isbn ? doc.isbn[0] : undefined;
      const pages = doc.number_of_pages_median || 320;
      const subjects = doc.subject ? doc.subject.slice(0, 4) : [];
      const primaryCategory = category !== 'all' ? category : (subjects[0] || 'General');

      return {
        id: `ol-${id}`,
        title: doc.title,
        author,
        coverUrl,
        rating: doc.ratings_average ? Math.round(doc.ratings_average * 10) / 10 : 4.2,
        ratingsCount: doc.ratings_count || 120,
        category: primaryCategory,
        description: `Discovered on Open Library. First published in ${doc.first_publish_year || 'historical records'}. Subjects include ${subjects.join(', ') || 'literature and humanities'}.`,
        publisher: doc.publisher ? doc.publisher[0] : 'Various Publishers',
        publishedDate: doc.first_publish_year ? `${doc.first_publish_year}` : undefined,
        pageCount: pages,
        isbn,
        language: doc.language ? doc.language[0] : 'eng',
        subjects,
        readingLinks: [
          {
            label: 'View on Open Library',
            url: `https://openlibrary.org${doc.key}`,
            type: 'open_library',
          },
        ],
      };
    });

    // Merge any high quality local matches that match query at the front
    const uniqueBookMap = new Map<string, Book>();
    localMatches.forEach((b) => uniqueBookMap.set(b.id, b));
    mappedBooks.forEach((b) => {
      if (!uniqueBookMap.has(b.id)) {
        uniqueBookMap.set(b.id, b);
      }
    });

    const combined = Array.from(uniqueBookMap.values());

    return {
      books: combined,
      total: data.numFound || combined.length,
      source: 'open_library',
    };
  } catch {
    // Graceful fallback to local matches when network fails or times out
    return {
      books: localMatches,
      total: localMatches.length,
      source: 'local',
    };
  }
}
