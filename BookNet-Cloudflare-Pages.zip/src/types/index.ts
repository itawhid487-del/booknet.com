export type ReadingStatus = 'want_to_read' | 'currently_reading' | 'finished';

export interface Book {
  id: string;
  title: string;
  author: string;
  coverUrl: string;
  rating: number;
  ratingsCount: number;
  category: string;
  description: string;
  publisher?: string;
  publishedDate?: string;
  pageCount: number;
  isbn?: string;
  language?: string;
  subjects?: string[];
  readingLinks?: {
    label: string;
    url: string;
    type: 'public_domain' | 'open_library' | 'preview';
  }[];
}

export interface LibraryBook {
  book: Book;
  status: ReadingStatus;
  currentPage: number;
  totalPages: number;
  rating?: number;
  notes?: string;
  startedAt?: string;
  finishedAt?: string;
  updatedAt: string;
  customShelves?: string[];
}

export interface ReadingList {
  id: string;
  title: string;
  description: string;
  isPublic: boolean;
  coverIcon: string;
  bookIds: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Review {
  id: string;
  bookId: string;
  bookTitle: string;
  bookCover: string;
  userId: string;
  userName: string;
  userAvatar: string;
  rating: number;
  title: string;
  content: string;
  containsSpoilers?: boolean;
  helpfulCount: number;
  helpfulUserIds?: string[];
  createdAt: string;
  reported?: boolean;
}

export interface Reply {
  id: string;
  authorName: string;
  authorAvatar: string;
  authorId: string;
  content: string;
  createdAt: string;
  likesCount: number;
}

export interface Discussion {
  id: string;
  category: 'Book Club' | 'Recommendations' | 'General Chat' | 'Reading Challenges';
  title: string;
  content: string;
  authorName: string;
  authorAvatar: string;
  authorId: string;
  repliesCount: number;
  likesCount: number;
  likedByUser?: boolean;
  createdAt: string;
  replies: Reply[];
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  targetBooks: number;
  currentCount: number;
  participantCount: number;
  joined: boolean;
  endDate: string;
  badgeIcon: string;
}

export interface UserProfile {
  id: string;
  name: string;
  username: string;
  email: string;
  avatar: string;
  bio: string;
  readingGoal: number; // e.g. 25 books a year
  favoriteGenres: string[];
  joinedDate: string;
}

export interface ReadingSession {
  id: string;
  bookId: string;
  bookTitle: string;
  pagesRead: number;
  durationMinutes: number;
  date: string; // ISO date YYYY-MM-DD
  notes?: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress: number;
  maxProgress: number;
  unlockedDate?: string;
}

export type ActivePage =
  | 'home'
  | 'discover'
  | 'book-detail'
  | 'library'
  | 'lists'
  | 'progress'
  | 'community'
  | 'reviews'
  | 'profile'
  | 'settings'
  | 'signin'
  | 'signup'
  | 'privacy'
  | 'terms'
  | 'contact';
