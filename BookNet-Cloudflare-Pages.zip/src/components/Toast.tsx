import React from 'react';
import { CheckCircle2, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Toast: React.FC = () => {
  const { notification, clearNotification } = useApp();

  if (!notification) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-sm flex items-center gap-3 p-4 rounded-2xl bg-[#173D30] border border-[#C6A15B]/50 shadow-2xl text-[#F7F3EA] animate-in fade-in slide-in-from-bottom-5 duration-300">
      <CheckCircle2 className="w-5 h-5 text-[#C6A15B] shrink-0" />
      <p className="text-xs font-medium leading-relaxed flex-1">{notification}</p>
      <button
        onClick={clearNotification}
        className="p-1 rounded-lg hover:bg-[#10241F] text-[#E9E1D2]/70 hover:text-white transition-colors cursor-pointer"
        aria-label="Dismiss notification"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
};
