import React from 'react';
import { Star, Plus, Check } from 'lucide-react';
import { Book } from '../types/index';
import { useApp } from '../context/AppContext';

interface BookCardProps {
  book: Book;
  showCategory?: boolean;
}

export const BookCard: React.FC<BookCardProps> = ({ book, showCategory = true }) => {
  const { setSelectedBookId, setActivePage, library, addToLibrary } = useApp();

  const libraryItem = library.find((b) => b.book.id === book.id);
  const isInLibrary = !!libraryItem;

  const handleClick = () => {
    setSelectedBookId(book.id);
    setActivePage('book-detail');
  };

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isInLibrary) {
      addToLibrary(book, 'want_to_read');
    }
  };

  const formattedCount =
    book.ratingsCount >= 1000
      ? `${(book.ratingsCount / 1000).toFixed(1)}k`
      : `${book.ratingsCount}`;

  return (
    <div
      onClick={handleClick}
      className="group relative bg-[#173D30]/40 hover:bg-[#173D30]/80 border border-[#254d3e]/70 hover:border-[#C6A15B]/50 rounded-2xl p-3.5 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 cursor-pointer flex flex-col justify-between"
    >
      <div>
        {/* Cover Image Container */}
        <div className="relative aspect-3/4 rounded-xl overflow-hidden bg-[#10241F] mb-3 shadow-md group-hover:shadow-lg transition-shadow">
          <img
            src={book.coverUrl}
            alt={book.title}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            onError={(e) => {
              // Fallback cover if image fails
              (e.currentTarget as HTMLImageElement).src =
                'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=600';
            }}
          />

          {/* Quick Add Overlay Button */}
          <button
            onClick={handleQuickAdd}
            title={isInLibrary ? `In library (${libraryItem.status.replace(/_/g, ' ')})` : 'Add to Want to Read'}
            className={`absolute top-2 right-2 w-7 h-7 rounded-full flex items-center justify-center transition-all ${
              isInLibrary
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-[#10241F]/80 text-[#F7F3EA] hover:bg-[#C6A15B] hover:text-[#10241F] opacity-0 group-hover:opacity-100 shadow-sm'
            }`}
          >
            {isInLibrary ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Title & Author */}
        <h4 className="font-serif font-bold text-sm text-[#F7F3EA] line-clamp-1 group-hover:text-[#C6A15B] transition-colors">
          {book.title}
        </h4>
        <p className="text-xs text-[#E9E1D2]/70 mt-0.5 line-clamp-1">
          {book.author}
        </p>
      </div>

      {/* Rating & Category Footer */}
      <div className="mt-2.5 pt-2 border-t border-[#254d3e]/50 flex items-center justify-between gap-1 text-[11px]">
        <div className="flex items-center gap-1 text-[#C6A15B] font-semibold">
          <Star className="w-3.5 h-3.5 fill-[#C6A15B] text-[#C6A15B]" />
          <span>{book.rating.toFixed(1)}</span>
          <span className="text-[#E9E1D2]/50 font-normal">({formattedCount})</span>
        </div>

        {showCategory && (
          <span className="px-2 py-0.5 rounded-full bg-[#10241F] border border-[#254d3e] text-[10px] text-[#E9E1D2]/80 font-medium">
            {book.category}
          </span>
        )}
      </div>
    </div>
  );
};
