import React from 'react';
import {
  Home,
  Compass,
  BookOpen,
  Bookmark,
  Users,
  Trophy,
  Settings,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ActivePage } from '../types/index';

interface SidebarProps {
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isMobileOpen, onCloseMobile }) => {
  const { activePage, setActivePage } = useApp();

  const navItems: { id: ActivePage; label: string; icon: React.ElementType }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'discover', label: 'Discover', icon: Compass },
    { id: 'library', label: 'My Library', icon: BookOpen },
    { id: 'lists', label: 'Reading Lists', icon: Bookmark },
    { id: 'community', label: 'Community', icon: Users },
    { id: 'progress', label: 'Achievements', icon: Trophy },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleNav = (page: ActivePage) => {
    setActivePage(page);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs md:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed md:sticky top-0 left-0 z-50 h-screen w-64 shrink-0 flex flex-col justify-between bg-[#10241F] border-r border-[#173D30]/70 text-[#F7F3EA] overflow-y-auto transition-transform duration-300 ease-in-out md:translate-x-0 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={() => handleNav('home')}
              className="flex items-center gap-3 group text-left cursor-pointer"
            >
              {/* Original BookNet Logo Icon */}
              <div className="w-10 h-10 rounded-xl bg-[#173D30] border border-[#C6A15B]/40 flex items-center justify-center text-[#C6A15B] shadow-inner group-hover:border-[#C6A15B] transition-colors">
                <svg
                  className="w-6 h-6"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5Z" />
                  <path d="M6 6h10" />
                  <path d="M6 10h10" />
                  <path d="M6 14h7" />
                  <path d="m19 2-4 4 4 4" />
                </svg>
              </div>
              <div>
                <span className="font-serif text-2xl font-bold tracking-tight text-[#F7F3EA] block leading-none">
                  BookNet
                </span>
                <span className="text-[11px] font-sans font-medium text-[#C6A15B] tracking-wider uppercase mt-1 block">
                  Read · Explore · Grow
                </span>
              </div>
            </button>

            {onCloseMobile && (
              <button
                onClick={onCloseMobile}
                className="p-1 rounded-lg hover:bg-[#173D30] md:hidden text-[#E9E1D2]"
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1.5" aria-label="Main Navigation">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl text-sm font-medium transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#173D30] text-[#F7F3EA] shadow-xs border-l-3 border-[#C6A15B]'
                      : 'text-[#E9E1D2]/80 hover:text-[#F7F3EA] hover:bg-[#173D30]/40'
                  }`}
                >
                  <Icon
                    className={`w-4.5 h-4.5 transition-colors ${
                      isActive ? 'text-[#C6A15B]' : 'text-[#E9E1D2]/60'
                    }`}
                  />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Atmospheric Silhouette Quote */}
        <div className="p-5 m-4 rounded-2xl bg-linear-to-b from-[#173D30]/50 to-[#0c1a16] border border-[#173D30] relative overflow-hidden">
          <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-[#C6A15B]/5 rounded-full blur-xl pointer-events-none" />
          <p className="font-serif italic text-xs leading-relaxed text-[#E9E1D2]/90 relative z-10">
            &ldquo;A book is a dream that you hold in your hands.&rdquo;
          </p>
          <p className="text-[11px] font-sans font-medium text-[#C6A15B] mt-2 block relative z-10">
            — Neil Gaiman
          </p>
        </div>
      </aside>
    </>
  );
};
