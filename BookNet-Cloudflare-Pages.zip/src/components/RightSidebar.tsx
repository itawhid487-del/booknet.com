import React from 'react';
import {
  Bookmark,
  BookOpen,
  CheckCircle2,
  ChevronRight,
  Gift,
  Users,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { calculateProgress } from '../utils/library';

export const RightSidebar: React.FC = () => {
  const { library, setActivePage, setSelectedBookId } = useApp();

  // Find currently reading book with highest progress or first
  const currentBooks = library.filter((b) => b.status === 'currently_reading');
  const activeBook = currentBooks[0] || library[0];

  const wantToReadCount = library.filter((b) => b.status === 'want_to_read').length;
  const currentlyReadingCount = currentBooks.length;
  const finishedCount = library.filter((b) => b.status === 'finished').length;

  const currentPercent = activeBook
    ? calculateProgress(activeBook.currentPage, activeBook.totalPages)
    : 0;

  return (
    <aside className="w-80 shrink-0 space-y-5 hidden xl:block">
      {/* 1. Your Reading Progress Widget */}
      <div className="p-5 rounded-2xl bg-[#173D30]/60 border border-[#254d3e] shadow-lg backdrop-blur-xs">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-serif font-semibold text-base text-[#F7F3EA]">
            Your Reading Progress
          </h3>
          <button
            onClick={() => {
              if (activeBook) {
                setSelectedBookId(activeBook.book.id);
                setActivePage('book-detail');
              } else {
                setActivePage('progress');
              }
            }}
            className="text-xs font-medium text-[#C6A15B] hover:text-[#d6b16b] flex items-center gap-1 cursor-pointer transition-colors"
          >
            <span>View Details</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {activeBook ? (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              {/* Circular Gauge */}
              <div className="relative w-18 h-18 shrink-0 flex items-center justify-center">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                  {/* Track */}
                  <path
                    className="text-[#10241F]"
                    strokeWidth="3.5"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  {/* Progress Indicator */}
                  <path
                    className="text-[#5eead4]"
                    strokeDasharray={`${currentPercent}, 100`}
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>
                <span className="absolute font-serif text-sm font-bold text-[#F7F3EA]">
                  {currentPercent}%
                </span>
              </div>

              {/* Book Info */}
              <div className="min-w-0 flex-1">
                <span className="text-[11px] font-medium uppercase tracking-wider text-[#E9E1D2]/60 block mb-0.5">
                  Currently Reading
                </span>
                <div className="flex items-center gap-2.5">
                  <img
                    src={activeBook.book.coverUrl}
                    alt={activeBook.book.title}
                    className="w-8 h-11 object-cover rounded-sm shadow-xs border border-[#254d3e] shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="font-serif font-semibold text-xs text-[#F7F3EA] truncate">
                      {activeBook.book.title}
                    </p>
                    <p className="text-[11px] text-[#E9E1D2]/70 truncate">
                      {activeBook.book.author}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Linear Progress Bar */}
            <div className="space-y-1.5 pt-1">
              <div className="w-full bg-[#10241F] h-2 rounded-full overflow-hidden p-0.5">
                <div
                  className="bg-linear-to-r from-[#2dd4bf] to-[#14b8a6] h-full rounded-full transition-all duration-500"
                  style={{ width: `${currentPercent}%` }}
                />
              </div>
              <div className="flex justify-between items-center text-[11px] text-[#E9E1D2]/60">
                <span>Progress</span>
                <span className="font-medium text-[#F7F3EA]">
                  {activeBook.currentPage} / {activeBook.totalPages} pages
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-4 text-center text-xs text-[#E9E1D2]/60">
            No active book in reading list.
          </div>
        )}
      </div>

      {/* 2. Your Reading Lists Widget */}
      <div className="p-5 rounded-2xl bg-[#173D30]/60 border border-[#254d3e] shadow-lg backdrop-blur-xs">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-serif font-semibold text-base text-[#F7F3EA]">
            Your Reading Lists
          </h3>
          <button
            onClick={() => setActivePage('library')}
            className="text-xs font-medium text-[#C6A15B] hover:text-[#d6b16b] flex items-center gap-1 cursor-pointer transition-colors"
          >
            <span>View All</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-2.5">
          {/* Want to Read */}
          <button
            onClick={() => setActivePage('library')}
            className="w-full flex items-center justify-between p-3 rounded-xl bg-[#10241F]/50 border border-[#254d3e]/60 hover:bg-[#10241F] hover:border-[#C6A15B]/40 transition-all cursor-pointer group text-left"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-950/60 border border-emerald-800/40 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform">
                <Bookmark className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-medium text-[#F7F3EA]">Want to Read</p>
                <p className="text-[11px] text-[#E9E1D2]/60">{wantToReadCount} books</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#E9E1D2]/30 group-hover:text-[#C6A15B] group-hover:translate-x-0.5 transition-all" />
          </button>

          {/* Currently Reading */}
          <button
            onClick={() => setActivePage('library')}
            className="w-full flex items-center justify-between p-3 rounded-xl bg-[#10241F]/50 border border-[#254d3e]/60 hover:bg-[#10241F] hover:border-[#C6A15B]/40 transition-all cursor-pointer group text-left"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-sky-950/60 border border-sky-800/40 flex items-center justify-center text-sky-400 group-hover:scale-105 transition-transform">
                <BookOpen className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-medium text-[#F7F3EA]">Currently Reading</p>
                <p className="text-[11px] text-[#E9E1D2]/60">{currentlyReadingCount} books</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#E9E1D2]/30 group-hover:text-[#C6A15B] group-hover:translate-x-0.5 transition-all" />
          </button>

          {/* Finished */}
          <button
            onClick={() => setActivePage('library')}
            className="w-full flex items-center justify-between p-3 rounded-xl bg-[#10241F]/50 border border-[#254d3e]/60 hover:bg-[#10241F] hover:border-[#C6A15B]/40 transition-all cursor-pointer group text-left"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-purple-950/60 border border-purple-800/40 flex items-center justify-center text-purple-400 group-hover:scale-105 transition-transform">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-medium text-[#F7F3EA]">Finished</p>
                <p className="text-[11px] text-[#E9E1D2]/60">{finishedCount} books</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#E9E1D2]/30 group-hover:text-[#C6A15B] group-hover:translate-x-0.5 transition-all" />
          </button>
        </div>
      </div>

      {/* 3. Reading Inspiration Card */}
      <div className="relative rounded-2xl overflow-hidden p-6 border border-[#254d3e] shadow-lg group">
        <div
          className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105 opacity-30"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=600')`,
          }}
        />
        <div className="absolute inset-0 bg-linear-to-t from-[#10241F] via-[#10241F]/90 to-[#10241F]/70" />
        <div className="relative z-10 space-y-2">
          <p className="font-serif italic text-sm text-[#F7F3EA] leading-relaxed">
            &ldquo;Good books don&apos;t just tell stories, they change how we see the world.&rdquo;
          </p>
          <div className="w-8 h-0.5 bg-[#C6A15B] mt-3" />
        </div>
      </div>

      {/* 4. Join Our Community Widget */}
      <div className="p-5 rounded-2xl bg-[#173D30]/60 border border-[#254d3e] shadow-lg backdrop-blur-xs flex items-start gap-3.5">
        <div className="w-10 h-10 rounded-xl bg-[#10241F] border border-[#C6A15B]/30 flex items-center justify-center text-[#C6A15B] shrink-0 mt-0.5">
          <Users className="w-5 h-5" />
        </div>
        <div className="space-y-2">
          <h4 className="font-serif font-semibold text-sm text-[#F7F3EA]">
            Join Our Community
          </h4>
          <p className="text-xs text-[#E9E1D2]/70 leading-relaxed">
            Share your reviews, get recommendations, and connect with fellow book lovers.
          </p>
          <button
            onClick={() => setActivePage('community')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#10241F] text-xs font-semibold text-[#C6A15B] hover:bg-[#0c1a16] border border-[#254d3e] cursor-pointer transition-colors"
          >
            <span>Join Now</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 5. Read. Review. Earn. Widget */}
      <div className="p-5 rounded-2xl bg-[#173D30]/60 border border-[#254d3e] shadow-lg backdrop-blur-xs flex items-center justify-between gap-3">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <Gift className="w-4 h-4 text-[#C6A15B]" />
            <h4 className="font-serif font-semibold text-sm text-[#F7F3EA]">
              Read. Review. Earn.
            </h4>
          </div>
          <p className="text-xs text-[#E9E1D2]/70 leading-relaxed">
            Write reviews and earn badges and reading laurels!
          </p>
          <button
            onClick={() => setActivePage('reviews')}
            className="text-xs font-medium text-[#C6A15B] hover:underline flex items-center gap-1 cursor-pointer pt-1"
          >
            <span>Learn More</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>
        <div className="text-2xl select-none">📚</div>
      </div>
    </aside>
  );
};
