import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  Home,
  BookOpen,
  Users,
  Bell,
  ChevronDown,
  Menu,
  User,
  LogOut,
  LogIn,
  Sliders,
  Check,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface TopNavbarProps {
  onOpenMobileMenu: () => void;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({ onOpenMobileMenu }) => {
  const {
    activePage,
    setActivePage,
    searchQuery,
    setSearchQuery,
    currentUser,
    signOut,
    signIn,
    showToast,
  } = useApp();

  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(1);
  const profileRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  // Close popovers on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setIsProfileOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setIsNotificationOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (activePage !== 'discover') {
      setActivePage('discover');
    }
  };

  return (
    <header className="sticky top-0 z-30 w-full bg-[#10241F]/90 backdrop-blur-md border-b border-[#173D30]/60 px-4 md:px-8 py-3.5 flex items-center justify-between gap-4">
      {/* Left: Mobile menu button & Search Bar */}
      <div className="flex items-center gap-3 flex-1 max-w-xl">
        <button
          onClick={onOpenMobileMenu}
          className="p-2 rounded-xl text-[#E9E1D2] hover:bg-[#173D30] md:hidden cursor-pointer"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <form onSubmit={handleSearchSubmit} className="relative w-full">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#E9E1D2]/50" />
            <input
              type="text"
              placeholder="Search books, authors, genres..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => {
                if (activePage !== 'discover' && searchQuery.trim().length > 0) {
                  setActivePage('discover');
                }
              }}
              className="w-full pl-10 pr-4 py-2 bg-[#173D30]/50 border border-[#173D30] hover:border-[#C6A15B]/40 focus:border-[#C6A15B] rounded-full text-sm text-[#F7F3EA] placeholder-[#E9E1D2]/40 outline-hidden transition-all shadow-inner"
            />
          </div>
        </form>
      </div>

      {/* Right Controls: Quick Navigation, Notifications & User Profile */}
      <div className="flex items-center gap-2 md:gap-5">
        {/* Quick Nav Links (Desktop) */}
        <nav className="hidden lg:flex items-center gap-1 border-r border-[#173D30] pr-4">
          <button
            onClick={() => setActivePage('home')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
              activePage === 'home'
                ? 'text-[#C6A15B] bg-[#173D30]/60 font-semibold'
                : 'text-[#E9E1D2]/80 hover:text-[#F7F3EA] hover:bg-[#173D30]/30'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Home</span>
          </button>
          <button
            onClick={() => setActivePage('library')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
              activePage === 'library'
                ? 'text-[#C6A15B] bg-[#173D30]/60 font-semibold'
                : 'text-[#E9E1D2]/80 hover:text-[#F7F3EA] hover:bg-[#173D30]/30'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Library</span>
          </button>
          <button
            onClick={() => setActivePage('community')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
              activePage === 'community'
                ? 'text-[#C6A15B] bg-[#173D30]/60 font-semibold'
                : 'text-[#E9E1D2]/80 hover:text-[#F7F3EA] hover:bg-[#173D30]/30'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Community</span>
          </button>
        </nav>

        {/* Notifications Icon with Badge */}
        <div className="relative" ref={notifRef}>
          <button
            onClick={() => {
              setIsNotificationOpen(!isNotificationOpen);
              setUnreadCount(0);
            }}
            aria-label="View notifications"
            className="relative p-2 rounded-xl text-[#E9E1D2] hover:bg-[#173D30] transition-colors cursor-pointer"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#C6A15B] ring-2 ring-[#10241F]" />
            )}
          </button>

          {/* Notifications Dropdown */}
          {isNotificationOpen && (
            <div className="absolute right-0 mt-2 w-80 rounded-2xl bg-[#173D30] border border-[#254d3e] shadow-2xl p-4 z-50 text-left">
              <div className="flex items-center justify-between pb-3 border-b border-[#254d3e]">
                <h4 className="font-serif font-semibold text-sm text-[#F7F3EA]">Notifications</h4>
                <span className="text-[11px] text-[#C6A15B]">Mark all read</span>
              </div>
              <div className="py-3 space-y-3">
                <div className="flex items-start gap-3 p-2 rounded-xl bg-[#10241F]/40 border border-[#254d3e]/50">
                  <div className="w-2 h-2 mt-1.5 rounded-full bg-[#C6A15B] shrink-0" />
                  <div>
                    <p className="text-xs text-[#F7F3EA] font-medium leading-relaxed">
                      You are 40% through &ldquo;The Midnight Library&rdquo;!
                    </p>
                    <span className="text-[10px] text-[#E9E1D2]/60 mt-1 block">2 hours ago</span>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-2 rounded-xl hover:bg-[#10241F]/20">
                  <div className="w-2 h-2 mt-1.5 rounded-full bg-emerald-400 shrink-0" />
                  <div>
                    <p className="text-xs text-[#E9E1D2] leading-relaxed">
                      Sarah Jenkins liked your review of &ldquo;Atomic Habits&rdquo;.
                    </p>
                    <span className="text-[10px] text-[#E9E1D2]/60 mt-1 block">Yesterday</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User Profile / Auth Control */}
        <div className="relative" ref={profileRef}>
          {currentUser ? (
            <button
              onClick={() => setIsProfileOpen(!isProfileOpen)}
              className="flex items-center gap-2.5 pl-1.5 pr-2.5 py-1 rounded-full bg-[#173D30]/70 border border-[#173D30] hover:border-[#C6A15B]/50 transition-all cursor-pointer"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-7 h-7 rounded-full object-cover border border-[#C6A15B]/40"
              />
              <span className="text-sm font-medium text-[#F7F3EA] hidden sm:inline">
                {currentUser.name}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-[#E9E1D2]/60" />
            </button>
          ) : (
            <button
              onClick={() => setActivePage('signin')}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#C6A15B] text-[#10241F] font-semibold text-xs hover:bg-[#d6b16b] transition-colors cursor-pointer"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
          )}

          {/* User Menu Dropdown */}
          {isProfileOpen && currentUser && (
            <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-[#173D30] border border-[#254d3e] shadow-2xl p-2 z-50 text-left">
              <div className="px-3 py-2 border-b border-[#254d3e]">
                <p className="text-sm font-semibold text-[#F7F3EA]">{currentUser.name}</p>
                <p className="text-xs text-[#E9E1D2]/60 truncate">@{currentUser.username}</p>
              </div>

              <div className="py-1">
                <button
                  onClick={() => {
                    setActivePage('profile');
                    setIsProfileOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-[#E9E1D2] hover:bg-[#10241F] hover:text-[#F7F3EA] cursor-pointer"
                >
                  <User className="w-3.5 h-3.5 text-[#C6A15B]" />
                  <span>Your Profile</span>
                </button>
                <button
                  onClick={() => {
                    setActivePage('progress');
                    setIsProfileOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-[#E9E1D2] hover:bg-[#10241F] hover:text-[#F7F3EA] cursor-pointer"
                >
                  <Sliders className="w-3.5 h-3.5 text-[#C6A15B]" />
                  <span>Reading Dashboard</span>
                </button>
                <button
                  onClick={() => {
                    setActivePage('settings');
                    setIsProfileOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-[#E9E1D2] hover:bg-[#10241F] hover:text-[#F7F3EA] cursor-pointer"
                >
                  <Sliders className="w-3.5 h-3.5 text-[#C6A15B]" />
                  <span>Account Settings</span>
                </button>
              </div>

              <div className="pt-1 border-t border-[#254d3e]">
                <button
                  onClick={() => {
                    signIn('elena@example.com', 'Elena Rostova');
                    setIsProfileOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-3 py-1.5 rounded-xl text-xs text-[#E9E1D2]/80 hover:bg-[#10241F] cursor-pointer"
                >
                  <span>Switch to Elena</span>
                  <Check className="w-3 h-3 text-[#C6A15B]" />
                </button>
                <button
                  onClick={() => {
                    signOut();
                    setIsProfileOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-rose-300 hover:bg-rose-950/40 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
