import { LibraryBook, ReadingSession, Achievement, ReadingStatus } from '../types/index';

/**
 * Calculates percentage completion safely capped between 0 and 100
 */
export function calculateProgress(currentPage: number, totalPages: number): number {
  if (!totalPages || totalPages <= 0) return 0;
  if (!currentPage || currentPage <= 0) return 0;
  const percent = Math.round((currentPage / totalPages) * 100);
  return Math.min(100, Math.max(0, percent));
}

/**
 * Calculates reading goal stats for the current year
 */
export function calculateReadingGoalStats(books: LibraryBook[], annualGoal: number) {
  const currentYear = new Date().getFullYear();
  const finishedThisYear = books.filter((item) => {
    if (item.status !== 'finished') return false;
    if (!item.finishedAt) return true; // count if no explicit date given
    const finishedYear = new Date(item.finishedAt).getFullYear();
    return finishedYear === currentYear;
  });

  const finishedCount = finishedThisYear.length;
  const safeGoal = Math.max(1, annualGoal || 12);
  const percentage = Math.min(100, Math.round((finishedCount / safeGoal) * 100));

  // Day of year calculation for pacing
  const now = new Date();
  const startOfYear = new Date(now.getFullYear(), 0, 1);
  const dayOfYear = Math.floor((now.getTime() - startOfYear.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  const isLeapYear = (year: number) => (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const totalDays = isLeapYear(now.getFullYear()) ? 366 : 365;
  const expectedPace = (safeGoal / totalDays) * dayOfYear;
  const aheadOrBehind = Math.round((finishedCount - expectedPace) * 10) / 10;

  return {
    finishedCount,
    annualGoal: safeGoal,
    percentage,
    aheadOrBehind,
    daysRemaining: totalDays - dayOfYear,
  };
}

/**
 * Filters and sorts personal library books
 */
export function filterAndSortBooks(
  books: LibraryBook[],
  query: string = '',
  statusFilter: string = 'all',
  sortBy: string = 'recent',
  genreFilter: string = 'all'
): LibraryBook[] {
  let result = [...books];

  // Status filtering
  if (statusFilter !== 'all') {
    result = result.filter((b) => b.status === statusFilter);
  }

  // Genre filtering
  if (genreFilter !== 'all') {
    result = result.filter(
      (b) => b.book.category.toLowerCase() === genreFilter.toLowerCase()
    );
  }

  // Text search filtering (title, author, notes)
  if (query.trim()) {
    const q = query.toLowerCase().trim();
    result = result.filter(
      (b) =>
        b.book.title.toLowerCase().includes(q) ||
        b.book.author.toLowerCase().includes(q) ||
        (b.notes && b.notes.toLowerCase().includes(q))
    );
  }

  // Sorting
  switch (sortBy) {
    case 'title_asc':
      result.sort((a, b) => a.book.title.localeCompare(b.book.title));
      break;
    case 'title_desc':
      result.sort((a, b) => b.book.title.localeCompare(a.book.title));
      break;
    case 'author':
      result.sort((a, b) => a.book.author.localeCompare(b.book.author));
      break;
    case 'progress_desc':
      result.sort((a, b) => {
        const pA = calculateProgress(a.currentPage, a.totalPages);
        const pB = calculateProgress(b.currentPage, b.totalPages);
        return pB - pA;
      });
      break;
    case 'rating_desc':
      result.sort((a, b) => (b.rating || 0) - (a.rating || 0));
      break;
    case 'recent':
    default:
      result.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      break;
  }

  return result;
}

/**
 * Groups reading sessions for the last 7 days
 */
export function calculateWeeklyPages(sessions: ReadingSession[]): { day: string; date: string; pages: number }[] {
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const result: { day: string; date: string; pages: number }[] = [];
  const now = new Date();

  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(now.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    const dayLabel = days[d.getDay()];

    const pagesOnDay = sessions
      .filter((s) => s.date === dateStr)
      .reduce((sum, s) => sum + (s.pagesRead || 0), 0);

    result.push({
      day: dayLabel,
      date: dateStr,
      pages: pagesOnDay,
    });
  }

  return result;
}

/**
 * Evaluates achievements based on current library and sessions
 */
export function checkAchievements(books: LibraryBook[], sessions: ReadingSession[]): Achievement[] {
  const finishedCount = books.filter((b) => b.status === 'finished').length;
  const totalPagesRead = sessions.reduce((acc, s) => acc + (s.pagesRead || 0), 0) +
    books.reduce((acc, b) => acc + (b.status === 'finished' ? b.totalPages : b.currentPage), 0);
  
  const uniqueGenres = new Set(books.map((b) => b.book.category.toLowerCase())).size;
  const reviewedCount = books.filter((b) => (b.rating && b.rating > 0) || (b.notes && b.notes.length > 10)).length;

  return [
    {
      id: 'first_book',
      title: 'First Step',
      description: 'Finish your first book on BookNet',
      icon: 'BookOpen',
      progress: Math.min(1, finishedCount),
      maxProgress: 1,
      unlocked: finishedCount >= 1,
      unlockedDate: finishedCount >= 1 ? 'Unlocked' : undefined,
    },
    {
      id: 'bookworm',
      title: 'Avid Bookworm',
      description: 'Read and complete 5 books',
      icon: 'Award',
      progress: Math.min(5, finishedCount),
      maxProgress: 5,
      unlocked: finishedCount >= 5,
      unlockedDate: finishedCount >= 5 ? 'Unlocked' : undefined,
    },
    {
      id: 'page_turner',
      title: 'Page Master',
      description: 'Read over 1,000 total pages',
      icon: 'Layers',
      progress: Math.min(1000, totalPagesRead),
      maxProgress: 1000,
      unlocked: totalPagesRead >= 1000,
      unlockedDate: totalPagesRead >= 1000 ? 'Unlocked' : undefined,
    },
    {
      id: 'genre_explorer',
      title: 'Genre Explorer',
      description: 'Read across at least 4 distinct genres',
      icon: 'Compass',
      progress: Math.min(4, uniqueGenres),
      maxProgress: 4,
      unlocked: uniqueGenres >= 4,
      unlockedDate: uniqueGenres >= 4 ? 'Unlocked' : undefined,
    },
    {
      id: 'literary_critic',
      title: 'Literary Critic',
      description: 'Rate or write notes for at least 3 books',
      icon: 'PenTool',
      progress: Math.min(3, reviewedCount),
      maxProgress: 3,
      unlocked: reviewedCount >= 3,
      unlockedDate: reviewedCount >= 3 ? 'Unlocked' : undefined,
    },
  ];
}
