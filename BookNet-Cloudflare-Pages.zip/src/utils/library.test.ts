import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateProgress,
  calculateReadingGoalStats,
  filterAndSortBooks,
  checkAchievements,
} from './library';
import { LibraryBook } from '../types/index';

test('calculateProgress correctly handles normal and edge cases', () => {
  assert.equal(calculateProgress(120, 300), 40);
  assert.equal(calculateProgress(0, 300), 0);
  assert.equal(calculateProgress(300, 300), 100);
  assert.equal(calculateProgress(350, 300), 100); // capped at 100
  assert.equal(calculateProgress(-10, 300), 0); // lower bounded
  assert.equal(calculateProgress(50, 0), 0); // divide by zero guard
});

test('calculateReadingGoalStats calculates correct progress and pacing', () => {
  const currentYear = new Date().getFullYear();
  const mockBooks: LibraryBook[] = [
    {
      book: {
        id: '1',
        title: 'Book A',
        author: 'Author A',
        coverUrl: '',
        rating: 4.5,
        ratingsCount: 10,
        category: 'Fiction',
        description: '',
        pageCount: 200,
      },
      status: 'finished',
      currentPage: 200,
      totalPages: 200,
      finishedAt: `${currentYear}-02-15`,
      updatedAt: `${currentYear}-02-15`,
    },
    {
      book: {
        id: '2',
        title: 'Book B',
        author: 'Author B',
        coverUrl: '',
        rating: 4.0,
        ratingsCount: 5,
        category: 'Sci-Fi',
        description: '',
        pageCount: 300,
      },
      status: 'finished',
      currentPage: 300,
      totalPages: 300,
      finishedAt: `${currentYear}-03-20`,
      updatedAt: `${currentYear}-03-20`,
    },
    {
      book: {
        id: '3',
        title: 'Book C',
        author: 'Author C',
        coverUrl: '',
        rating: 5.0,
        ratingsCount: 2,
        category: 'Fantasy',
        description: '',
        pageCount: 400,
      },
      status: 'currently_reading',
      currentPage: 150,
      totalPages: 400,
      updatedAt: `${currentYear}-04-01`,
    },
  ];

  const stats = calculateReadingGoalStats(mockBooks, 10);
  assert.equal(stats.finishedCount, 2);
  assert.equal(stats.annualGoal, 10);
  assert.equal(stats.percentage, 20);
});

test('filterAndSortBooks filters by status, search query, and sorts correctly', () => {
  const mockBooks: LibraryBook[] = [
    {
      book: {
        id: '1',
        title: 'Dune',
        author: 'Frank Herbert',
        coverUrl: '',
        rating: 4.8,
        ratingsCount: 100,
        category: 'Sci-Fi',
        description: 'Epic space sci-fi',
        pageCount: 600,
      },
      status: 'currently_reading',
      currentPage: 300,
      totalPages: 600,
      updatedAt: '2026-01-01T10:00:00Z',
    },
    {
      book: {
        id: '2',
        title: 'Atomic Habits',
        author: 'James Clear',
        coverUrl: '',
        rating: 4.6,
        ratingsCount: 500,
        category: 'Self-Help',
        description: 'Habit formation guide',
        pageCount: 320,
      },
      status: 'finished',
      currentPage: 320,
      totalPages: 320,
      rating: 5,
      notes: 'Life changing systems',
      updatedAt: '2026-02-01T10:00:00Z',
    },
  ];

  // Filter by status
  const finishedOnly = filterAndSortBooks(mockBooks, '', 'finished');
  assert.equal(finishedOnly.length, 1);
  assert.equal(finishedOnly[0].book.title, 'Atomic Habits');

  // Search by keyword
  const searchResult = filterAndSortBooks(mockBooks, 'herbert');
  assert.equal(searchResult.length, 1);
  assert.equal(searchResult[0].book.title, 'Dune');

  // Search by notes
  const notesResult = filterAndSortBooks(mockBooks, 'systems');
  assert.equal(notesResult.length, 1);
  assert.equal(notesResult[0].book.title, 'Atomic Habits');

  // Sort by title
  const sortedTitleAsc = filterAndSortBooks(mockBooks, '', 'all', 'title_asc');
  assert.equal(sortedTitleAsc[0].book.title, 'Atomic Habits');
  assert.equal(sortedTitleAsc[1].book.title, 'Dune');
});

test('checkAchievements detects unlocked milestones', () => {
  const mockBooks: LibraryBook[] = Array(5).fill(null).map((_, i) => ({
    book: {
      id: `b${i}`,
      title: `Book ${i}`,
      author: `Author ${i}`,
      coverUrl: '',
      rating: 4.5,
      ratingsCount: 10,
      category: i === 0 ? 'Sci-Fi' : i === 1 ? 'Fantasy' : i === 2 ? 'Mystery' : 'Fiction',
      description: '',
      pageCount: 300,
    },
    status: 'finished',
    currentPage: 300,
    totalPages: 300,
    rating: 4,
    notes: 'Great read',
    updatedAt: '2026-01-01',
  }));

  const achievements = checkAchievements(mockBooks, []);
  const bookworm = achievements.find((a) => a.id === 'bookworm');
  assert.equal(bookworm?.unlocked, true);
  assert.equal(bookworm?.progress, 5);

  const pageTurner = achievements.find((a) => a.id === 'page_turner');
  assert.equal(pageTurner?.unlocked, true); // 5 * 300 = 1500 > 1000
});
