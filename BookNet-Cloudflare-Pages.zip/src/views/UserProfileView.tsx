import React, { useState } from 'react';
import {
  User,
  Edit2,
  BookOpen,
  CheckCircle2,
  Bookmark,
  Calendar,
  Award,
  Star,
  Settings,
  Mail,
  Sliders,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { BookCard } from '../components/BookCard';

export const UserProfileView: React.FC = () => {
  const {
    currentUser,
    updateProfile,
    library,
    reviews,
    readingLists,
    setActivePage,
  } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(currentUser?.name || '');
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [readingGoal, setReadingGoal] = useState<number>(currentUser?.readingGoal || 25);
  const [genresInput, setGenresInput] = useState(
    currentUser?.favoriteGenres.join(', ') || ''
  );

  if (!currentUser) {
    return (
      <div className="py-20 text-center space-y-4">
        <h2 className="font-serif text-2xl font-bold text-[#F7F3EA]">
          Please sign in to view your profile
        </h2>
        <button
          onClick={() => setActivePage('signin')}
          className="px-6 py-2.5 rounded-full bg-[#C6A15B] text-[#10241F] font-bold text-xs"
        >
          Sign In to BookNet
        </button>
      </div>
    );
  }

  const finishedCount = library.filter((b) => b.status === 'finished').length;
  const currentlyReadingCount = library.filter((b) => b.status === 'currently_reading').length;
  const wantToReadCount = library.filter((b) => b.status === 'want_to_read').length;
  const userReviews = reviews.filter((r) => r.userId === currentUser.id);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name,
      bio,
      readingGoal,
      favoriteGenres: genresInput.split(',').map((g) => g.trim()).filter(Boolean),
    });
    setIsEditing(false);
  };

  return (
    <div className="space-y-8">
      {/* Profile Header Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-[#173D30]/60 border border-[#254d3e] shadow-xl p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-24 h-24 rounded-full object-cover border-2 border-[#C6A15B] shadow-lg"
            />
            <div className="space-y-1.5">
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#F7F3EA]">
                  {currentUser.name}
                </h1>
                <span className="text-xs text-[#C6A15B] font-semibold bg-[#10241F] px-2.5 py-0.5 rounded-full border border-[#254d3e]">
                  Reader
                </span>
              </div>
              <p className="text-xs text-[#E9E1D2]/60">@{currentUser.username}</p>
              <p className="text-xs text-[#E9E1D2]/80 max-w-lg leading-relaxed pt-1">
                {currentUser.bio}
              </p>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 pt-2 text-[11px] text-[#E9E1D2]/60">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-[#C6A15B]" /> Joined {currentUser.joinedDate}
                </span>
                <span className="flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-[#C6A15B]" /> {currentUser.email}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-center sm:self-start">
            <button
              onClick={() => setIsEditing(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#10241F] border border-[#254d3e] hover:border-[#C6A15B] text-xs font-semibold text-[#F7F3EA] transition-colors cursor-pointer"
            >
              <Edit2 className="w-3.5 h-3.5 text-[#C6A15B]" />
              <span>Edit Profile</span>
            </button>
            <button
              onClick={() => setActivePage('settings')}
              className="p-2 rounded-xl bg-[#10241F] border border-[#254d3e] hover:border-[#C6A15B] text-[#E9E1D2] transition-colors cursor-pointer"
              title="Settings"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Favorite Genres Tags */}
        <div className="mt-6 pt-5 border-t border-[#254d3e]/60 flex flex-wrap items-center gap-2">
          <span className="text-xs text-[#E9E1D2]/60">Favorite Genres:</span>
          {currentUser.favoriteGenres.map((g, idx) => (
            <span
              key={idx}
              className="px-3 py-1 rounded-full bg-[#10241F] border border-[#254d3e] text-xs font-medium text-[#C6A15B]"
            >
              {g}
            </span>
          ))}
        </div>
      </div>

      {/* Reader Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[#173D30]/40 border border-[#254d3e] text-center">
          <span className="text-xs text-[#E9E1D2]/60 block mb-1">Finished</span>
          <span className="font-serif text-2xl font-bold text-[#F7F3EA]">{finishedCount}</span>
        </div>
        <div className="p-4 rounded-2xl bg-[#173D30]/40 border border-[#254d3e] text-center">
          <span className="text-xs text-[#E9E1D2]/60 block mb-1">Reading Now</span>
          <span className="font-serif text-2xl font-bold text-[#F7F3EA]">{currentlyReadingCount}</span>
        </div>
        <div className="p-4 rounded-2xl bg-[#173D30]/40 border border-[#254d3e] text-center">
          <span className="text-xs text-[#E9E1D2]/60 block mb-1">Queued</span>
          <span className="font-serif text-2xl font-bold text-[#F7F3EA]">{wantToReadCount}</span>
        </div>
        <div className="p-4 rounded-2xl bg-[#173D30]/40 border border-[#254d3e] text-center">
          <span className="text-xs text-[#E9E1D2]/60 block mb-1">Reviews Written</span>
          <span className="font-serif text-2xl font-bold text-[#C6A15B]">{userReviews.length}</span>
        </div>
      </div>

      {/* Currently Reading Bookshelf */}
      <div className="space-y-4">
        <h3 className="font-serif text-xl font-bold text-[#F7F3EA] flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-sky-400" />
          <span>On the Nightstand (Currently Reading)</span>
        </h3>
        {currentlyReadingCount > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {library
              .filter((b) => b.status === 'currently_reading')
              .map((b) => (
                <BookCard key={b.book.id} book={b.book} />
              ))}
          </div>
        ) : (
          <p className="text-xs text-[#E9E1D2]/60">No books currently being read.</p>
        )}
      </div>

      {/* My Written Reviews */}
      <div className="space-y-4">
        <h3 className="font-serif text-xl font-bold text-[#F7F3EA] flex items-center gap-2">
          <Star className="w-5 h-5 text-[#C6A15B]" />
          <span>My Written Reviews ({userReviews.length})</span>
        </h3>

        <div className="space-y-3">
          {userReviews.map((rev) => (
            <div
              key={rev.id}
              className="p-5 rounded-2xl bg-[#173D30]/40 border border-[#254d3e] space-y-2"
            >
              <div className="flex items-center justify-between">
                <h4 className="font-serif font-bold text-sm text-[#F7F3EA]">
                  {rev.bookTitle}
                </h4>
                <div className="flex items-center text-[#C6A15B] text-xs gap-1">
                  <Star className="w-3.5 h-3.5 fill-current" />
                  <span>{rev.rating}.0</span>
                </div>
              </div>
              <p className="text-xs text-[#E9E1D2]/80 leading-relaxed">{rev.content}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Edit Profile Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-[#173D30] border border-[#254d3e] rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4 animate-in zoom-in-95">
            <h3 className="font-serif text-xl font-bold text-[#F7F3EA]">
              Edit Profile Information
            </h3>

            <form onSubmit={handleSaveProfile} className="space-y-3">
              <div>
                <label className="text-xs text-[#E9E1D2]/80 block mb-1">Display Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
                />
              </div>

              <div>
                <label className="text-xs text-[#E9E1D2]/80 block mb-1">Bio</label>
                <textarea
                  rows={3}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full p-3 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
                />
              </div>

              <div>
                <label className="text-xs text-[#E9E1D2]/80 block mb-1">
                  Annual Reading Goal (Books)
                </label>
                <input
                  type="number"
                  min="1"
                  max="365"
                  value={readingGoal}
                  onChange={(e) => setReadingGoal(parseInt(e.target.value, 10) || 12)}
                  className="w-full px-4 py-2 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
                />
              </div>

              <div>
                <label className="text-xs text-[#E9E1D2]/80 block mb-1">
                  Favorite Genres (comma separated)
                </label>
                <input
                  type="text"
                  value={genresInput}
                  onChange={(e) => setGenresInput(e.target.value)}
                  placeholder="Fiction, Sci-Fi, Classics..."
                  className="w-full px-4 py-2 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 rounded-xl bg-[#10241F] text-xs font-medium text-[#E9E1D2]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#C6A15B] text-[#10241F] font-bold text-xs"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
