import React, { useState } from 'react';
import {
  Star,
  BookOpen,
  CheckCircle2,
  Bookmark,
  Share2,
  ExternalLink,
  ChevronLeft,
  Plus,
  Send,
  Trash2,
  ThumbsUp,
  AlertTriangle,
  Clock,
  Globe,
  Tag,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { INITIAL_BOOKS } from '../services/booksData';
import { ReadingStatus } from '../types/index';
import { BookCard } from '../components/BookCard';
import { calculateProgress } from '../utils/library';

export const BookDetailView: React.FC = () => {
  const {
    selectedBookId,
    setActivePage,
    library,
    addToLibrary,
    updateLibraryBook,
    removeFromLibrary,
    readingLists,
    toggleBookInList,
    reviews,
    addReview,
    deleteReview,
    toggleHelpfulReview,
    reportReview,
    currentUser,
    showToast,
  } = useApp();

  // Find book from INITIAL_BOOKS or from library
  const currentLibraryItem = library.find((item) => item.book.id === selectedBookId);
  const book =
    currentLibraryItem?.book ||
    INITIAL_BOOKS.find((b) => b.id === selectedBookId) ||
    INITIAL_BOOKS[0];

  // Local state for progress editing
  const [currentPageInput, setCurrentPageInput] = useState<number>(
    currentLibraryItem?.currentPage || 0
  );
  const [userNote, setUserNote] = useState<string>(currentLibraryItem?.notes || '');
  const [isAddingToList, setIsAddingToList] = useState(false);

  // Review Form state
  const [reviewRating, setReviewRating] = useState<number>(5);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewBody, setReviewBody] = useState('');
  const [containsSpoilers, setContainsSpoilers] = useState(false);
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);

  // Synchronize when library item updates
  React.useEffect(() => {
    if (currentLibraryItem) {
      setCurrentPageInput(currentLibraryItem.currentPage);
      setUserNote(currentLibraryItem.notes || '');
    }
  }, [currentLibraryItem]);

  const bookReviews = reviews.filter((r) => r.bookId === book.id);
  const relatedBooks = INITIAL_BOOKS.filter(
    (b) => b.id !== book.id && (b.category === book.category || b.author === book.author)
  ).slice(0, 4);

  const handleStatusChange = (status: ReadingStatus) => {
    addToLibrary(book, status);
  };

  const handleSaveProgress = () => {
    if (!currentLibraryItem) {
      addToLibrary(book, 'currently_reading');
    }
    const safePage = Math.max(0, Math.min(book.pageCount, currentPageInput));
    const status: ReadingStatus = safePage >= book.pageCount ? 'finished' : 'currently_reading';
    updateLibraryBook(book.id, {
      currentPage: safePage,
      status,
      notes: userNote,
    });
    showToast(`Updated progress: Page ${safePage} of ${book.pageCount}`);
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      showToast('Please sign in to post a review');
      return;
    }
    if (!reviewBody.trim() || !reviewTitle.trim()) {
      showToast('Please provide both a title and review thoughts');
      return;
    }

    setIsSubmittingReview(true);
    addReview({
      bookId: book.id,
      bookTitle: book.title,
      bookCover: book.coverUrl,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      rating: reviewRating,
      title: reviewTitle,
      content: reviewBody,
      containsSpoilers,
    });

    setReviewTitle('');
    setReviewBody('');
    setReviewRating(5);
    setContainsSpoilers(false);
    setIsSubmittingReview(false);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast('Book link copied to clipboard!');
    }
  };

  const currentPercent = currentLibraryItem
    ? calculateProgress(currentLibraryItem.currentPage, currentLibraryItem.totalPages)
    : 0;

  return (
    <div className="space-y-10">
      {/* Back button */}
      <div>
        <button
          onClick={() => setActivePage('discover')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#E9E1D2]/70 hover:text-[#C6A15B] transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to Discover</span>
        </button>
      </div>

      {/* Main Book Detail Banner Card */}
      <div className="p-6 md:p-8 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          {/* Left: Book Cover Image & Reading Status */}
          <div className="md:col-span-4 lg:col-span-3 space-y-4">
            <div className="relative aspect-3/4 rounded-2xl overflow-hidden shadow-2xl bg-[#10241F] border border-[#254d3e]">
              <img
                src={book.coverUrl}
                alt={book.title}
                className="w-full h-full object-cover"
              />
              {currentLibraryItem && (
                <div className="absolute top-3 left-3 bg-[#10241F]/90 backdrop-blur-md px-3 py-1 rounded-full border border-[#C6A15B]/50 text-[11px] font-semibold text-[#C6A15B] capitalize">
                  {currentLibraryItem.status.replace(/_/g, ' ')}
                </div>
              )}
            </div>

            {/* Quick Status Buttons */}
            <div className="space-y-2">
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  onClick={() => handleStatusChange('want_to_read')}
                  className={`py-2 px-1 text-[11px] font-semibold rounded-xl border transition-all cursor-pointer text-center ${
                    currentLibraryItem?.status === 'want_to_read'
                      ? 'bg-emerald-600 border-emerald-400 text-white shadow-xs'
                      : 'bg-[#10241F] border-[#254d3e] text-[#E9E1D2] hover:bg-[#10241F]/80 hover:border-[#C6A15B]'
                  }`}
                >
                  Want to Read
                </button>
                <button
                  onClick={() => handleStatusChange('currently_reading')}
                  className={`py-2 px-1 text-[11px] font-semibold rounded-xl border transition-all cursor-pointer text-center ${
                    currentLibraryItem?.status === 'currently_reading'
                      ? 'bg-sky-600 border-sky-400 text-white shadow-xs'
                      : 'bg-[#10241F] border-[#254d3e] text-[#E9E1D2] hover:bg-[#10241F]/80 hover:border-[#C6A15B]'
                  }`}
                >
                  Reading
                </button>
                <button
                  onClick={() => handleStatusChange('finished')}
                  className={`py-2 px-1 text-[11px] font-semibold rounded-xl border transition-all cursor-pointer text-center ${
                    currentLibraryItem?.status === 'finished'
                      ? 'bg-purple-600 border-purple-400 text-white shadow-xs'
                      : 'bg-[#10241F] border-[#254d3e] text-[#E9E1D2] hover:bg-[#10241F]/80 hover:border-[#C6A15B]'
                  }`}
                >
                  Finished
                </button>
              </div>

              {/* Add to Custom Reading List Dropdown toggle */}
              <div className="relative">
                <button
                  onClick={() => setIsAddingToList(!isAddingToList)}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#10241F] border border-[#254d3e] hover:border-[#C6A15B]/50 text-xs font-medium text-[#F7F3EA] transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 text-[#C6A15B]" />
                  <span>Add to Custom List</span>
                </button>

                {isAddingToList && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-[#10241F] border border-[#254d3e] rounded-xl p-2 shadow-2xl z-20 space-y-1">
                    <p className="text-[11px] font-semibold text-[#E9E1D2]/60 px-2 py-1">
                      Select Reading List
                    </p>
                    {readingLists.map((list) => {
                      const contains = list.bookIds.includes(book.id);
                      return (
                        <button
                          key={list.id}
                          onClick={() => toggleBookInList(list.id, book.id)}
                          className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs text-left hover:bg-[#173D30] cursor-pointer"
                        >
                          <span className="text-[#F7F3EA] truncate">{list.title}</span>
                          {contains && <CheckCircle2 className="w-3.5 h-3.5 text-[#C6A15B]" />}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {currentLibraryItem && (
                <button
                  onClick={() => removeFromLibrary(book.id)}
                  className="w-full flex items-center justify-center gap-1.5 text-[11px] text-rose-400/80 hover:text-rose-300 py-1 cursor-pointer transition-colors"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Remove from Library</span>
                </button>
              )}
            </div>
          </div>

          {/* Right: Book Details & Synopsis */}
          <div className="md:col-span-8 lg:col-span-9 space-y-6">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-[#10241F] border border-[#254d3e] text-xs font-semibold text-[#C6A15B]">
                    {book.category}
                  </span>
                  {book.language && (
                    <span className="px-2.5 py-1 rounded-full bg-[#10241F] border border-[#254d3e] text-[11px] text-[#E9E1D2]/70 flex items-center gap-1">
                      <Globe className="w-3 h-3" />
                      <span>{book.language.toUpperCase()}</span>
                    </span>
                  )}
                </div>

                <button
                  onClick={handleShare}
                  className="flex items-center gap-1.5 text-xs text-[#E9E1D2]/70 hover:text-[#F7F3EA] p-1.5 rounded-lg hover:bg-[#10241F] transition-colors cursor-pointer"
                  title="Share book link"
                >
                  <Share2 className="w-4 h-4" />
                  <span className="hidden sm:inline">Share</span>
                </button>
              </div>

              <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#F7F3EA] leading-tight">
                {book.title}
              </h1>
              <p className="text-base text-[#E9E1D2]/80 mt-1">
                by <span className="text-[#C6A15B] font-semibold">{book.author}</span>
              </p>

              {/* Rating Bar */}
              <div className="flex items-center gap-3 mt-3">
                <div className="flex items-center gap-1 text-[#C6A15B]">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-4 h-4 ${
                        star <= Math.round(book.rating)
                          ? 'fill-[#C6A15B] text-[#C6A15B]'
                          : 'text-[#E9E1D2]/30'
                      }`}
                    />
                  ))}
                  <span className="font-bold text-sm ml-1 text-[#F7F3EA]">
                    {book.rating.toFixed(1)}
                  </span>
                </div>
                <span className="text-xs text-[#E9E1D2]/50">
                  ({book.ratingsCount.toLocaleString()} verified ratings)
                </span>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <h3 className="font-serif font-semibold text-sm text-[#F7F3EA]">Synopsis</h3>
              <p className="text-sm text-[#E9E1D2]/80 leading-relaxed whitespace-pre-line">
                {book.description}
              </p>
            </div>

            {/* Book Metadata Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-2xl bg-[#10241F]/60 border border-[#254d3e] text-xs">
              <div>
                <span className="text-[#E9E1D2]/50 block">Publisher</span>
                <span className="font-medium text-[#F7F3EA] truncate block">
                  {book.publisher || 'Not Listed'}
                </span>
              </div>
              <div>
                <span className="text-[#E9E1D2]/50 block">Published Date</span>
                <span className="font-medium text-[#F7F3EA]">
                  {book.publishedDate || 'Unknown'}
                </span>
              </div>
              <div>
                <span className="text-[#E9E1D2]/50 block">Length</span>
                <span className="font-medium text-[#F7F3EA]">{book.pageCount} pages</span>
              </div>
              <div>
                <span className="text-[#E9E1D2]/50 block">ISBN</span>
                <span className="font-medium text-[#F7F3EA]">{book.isbn || 'N/A'}</span>
              </div>
            </div>

            {/* Subject Tags */}
            {book.subjects && book.subjects.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <Tag className="w-3.5 h-3.5 text-[#C6A15B] mr-1" />
                {book.subjects.map((s, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-0.5 rounded-full bg-[#10241F] border border-[#254d3e] text-[11px] text-[#E9E1D2]/70"
                  >
                    {s}
                  </span>
                ))}
              </div>
            )}

            {/* Authorized Reading & Catalog Links */}
            {book.readingLinks && book.readingLinks.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-[#254d3e]/60">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-[#C6A15B]">
                  Legitimate Reading & Catalog Links
                </h4>
                <div className="flex flex-wrap gap-2">
                  {book.readingLinks.map((link, idx) => (
                    <a
                      key={idx}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#10241F] hover:bg-[#10241F]/80 border border-[#254d3e] text-xs font-medium text-[#F7F3EA] hover:border-[#C6A15B] transition-colors"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-[#C6A15B]" />
                      <span>{link.label}</span>
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Reading Progress Tracker & Personal Notes Card */}
      <div className="p-6 md:p-8 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#254d3e] pb-4">
          <div>
            <h3 className="font-serif text-xl font-bold text-[#F7F3EA]">
              Personal Reading Tracker
            </h3>
            <p className="text-xs text-[#E9E1D2]/70">
              Record your current page number, reading reflections, and status.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-[#C6A15B]">
              {currentPercent}% Complete
            </span>
          </div>
        </div>

        {/* Interactive Progress Slider & Page Input */}
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <div className="flex-1 w-full space-y-1.5">
              <input
                type="range"
                min="0"
                max={book.pageCount}
                value={currentPageInput}
                onChange={(e) => setCurrentPageInput(parseInt(e.target.value, 10) || 0)}
                className="w-full h-2 bg-[#10241F] rounded-lg appearance-none cursor-pointer accent-[#C6A15B]"
              />
              <div className="flex justify-between text-xs text-[#E9E1D2]/60">
                <span>Page 0</span>
                <span>Page {book.pageCount}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs text-[#E9E1D2]/70">Page:</span>
              <input
                type="number"
                min="0"
                max={book.pageCount}
                value={currentPageInput}
                onChange={(e) => setCurrentPageInput(parseInt(e.target.value, 10) || 0)}
                className="w-20 px-3 py-1.5 bg-[#10241F] border border-[#254d3e] rounded-xl text-sm font-semibold text-[#F7F3EA] text-center focus:border-[#C6A15B] outline-hidden"
              />
              <span className="text-xs text-[#E9E1D2]/70">/ {book.pageCount}</span>
            </div>
          </div>

          {/* Personal Notes */}
          <div className="space-y-2">
            <label className="text-xs font-medium text-[#E9E1D2]/80 block">
              Private Reading Notes & Quotes
            </label>
            <textarea
              rows={3}
              value={userNote}
              onChange={(e) => setUserNote(e.target.value)}
              placeholder="Jot down memorable quotes, thoughts on chapter developments, or lessons learned..."
              className="w-full p-3.5 bg-[#10241F] border border-[#254d3e] rounded-2xl text-xs text-[#F7F3EA] placeholder-[#E9E1D2]/40 focus:border-[#C6A15B] outline-hidden leading-relaxed"
            />
          </div>

          <div className="flex justify-end">
            <button
              onClick={handleSaveProgress}
              className="px-5 py-2.5 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs transition-colors cursor-pointer"
            >
              Save Reading Progress
            </button>
          </div>
        </div>
      </div>

      {/* Community Reviews Section */}
      <div className="p-6 md:p-8 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] shadow-xl space-y-8">
        <div className="flex items-center justify-between border-b border-[#254d3e] pb-4">
          <div>
            <h3 className="font-serif text-xl font-bold text-[#F7F3EA]">Reader Reviews</h3>
            <p className="text-xs text-[#E9E1D2]/70">
              Verified community thoughts and ratings ({bookReviews.length})
            </p>
          </div>
        </div>

        {/* Write a Review Box */}
        <form
          onSubmit={handleSubmitReview}
          className="p-5 rounded-2xl bg-[#10241F]/80 border border-[#254d3e] space-y-4"
        >
          <h4 className="font-serif font-semibold text-sm text-[#F7F3EA]">
            Leave Your Review for &ldquo;{book.title}&rdquo;
          </h4>

          {/* Star Rating Select */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#E9E1D2]/70">Your Rating:</span>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <button
                  type="button"
                  key={s}
                  onClick={() => setReviewRating(s)}
                  className="p-1 hover:scale-110 transition-transform cursor-pointer"
                >
                  <Star
                    className={`w-5 h-5 ${
                      s <= reviewRating
                        ? 'fill-[#C6A15B] text-[#C6A15B]'
                        : 'text-[#E9E1D2]/30'
                    }`}
                  />
                </button>
              ))}
            </div>
            <span className="text-xs font-semibold text-[#C6A15B] ml-2">
              {reviewRating} out of 5 stars
            </span>
          </div>

          <input
            type="text"
            placeholder="Headline / Summary of your review..."
            value={reviewTitle}
            onChange={(e) => setReviewTitle(e.target.value)}
            className="w-full px-4 py-2.5 bg-[#173D30]/40 border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] placeholder-[#E9E1D2]/40 outline-hidden focus:border-[#C6A15B]"
          />

          <textarea
            rows={4}
            placeholder="What made this book memorable? Would you recommend it?"
            value={reviewBody}
            onChange={(e) => setReviewBody(e.target.value)}
            className="w-full p-4 bg-[#173D30]/40 border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] placeholder-[#E9E1D2]/40 outline-hidden focus:border-[#C6A15B] leading-relaxed"
          />

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <label className="flex items-center gap-2 text-xs text-[#E9E1D2]/70 cursor-pointer">
              <input
                type="checkbox"
                checked={containsSpoilers}
                onChange={(e) => setContainsSpoilers(e.target.checked)}
                className="rounded accent-[#C6A15B]"
              />
              <span>This review contains plot spoilers</span>
            </label>

            <button
              type="submit"
              disabled={isSubmittingReview}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs transition-colors cursor-pointer disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Post Review</span>
            </button>
          </div>
        </form>

        {/* Existing Reviews List */}
        <div className="space-y-4">
          {bookReviews.length > 0 ? (
            bookReviews.map((rev) => {
              const isAuthor = currentUser?.id === rev.userId;
              const hasLiked = currentUser && rev.helpfulUserIds?.includes(currentUser.id);
              return (
                <div
                  key={rev.id}
                  className={`p-5 rounded-2xl border transition-all ${
                    rev.reported
                      ? 'bg-rose-950/20 border-rose-900/40 opacity-70'
                      : 'bg-[#10241F]/60 border-[#254d3e]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-3">
                      <img
                        src={rev.userAvatar}
                        alt={rev.userName}
                        className="w-8 h-8 rounded-full object-cover border border-[#C6A15B]/30"
                      />
                      <div>
                        <span className="text-xs font-semibold text-[#F7F3EA]">
                          {rev.userName}
                        </span>
                        <div className="flex items-center gap-1 text-[#C6A15B] text-xs">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star
                              key={s}
                              className={`w-3 h-3 ${
                                s <= rev.rating
                                  ? 'fill-[#C6A15B] text-[#C6A15B]'
                                  : 'text-[#E9E1D2]/20'
                              }`}
                            />
                          ))}
                          <span className="text-[10px] text-[#E9E1D2]/50 ml-1">
                            {new Date(rev.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {isAuthor && (
                        <button
                          onClick={() => deleteReview(rev.id)}
                          className="p-1 text-rose-400 hover:bg-rose-950/40 rounded-lg cursor-pointer"
                          title="Delete your review"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        onClick={() => reportReview(rev.id)}
                        className="p-1 text-[#E9E1D2]/40 hover:text-amber-400 rounded-lg cursor-pointer"
                        title="Report review"
                      >
                        <AlertTriangle className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <h5 className="font-serif font-bold text-sm text-[#F7F3EA] mt-1 mb-1">
                    {rev.title}
                  </h5>

                  {rev.containsSpoilers && (
                    <span className="inline-block px-2 py-0.5 rounded-sm bg-amber-950/70 border border-amber-800 text-[10px] text-amber-300 mb-2">
                      Spoiler Alert
                    </span>
                  )}

                  <p className="text-xs text-[#E9E1D2]/80 leading-relaxed">{rev.content}</p>

                  <div className="mt-3 pt-2 border-t border-[#254d3e]/50 flex items-center justify-between text-xs">
                    <button
                      onClick={() => toggleHelpfulReview(rev.id)}
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[11px] transition-colors cursor-pointer ${
                        hasLiked
                          ? 'bg-[#C6A15B]/20 border-[#C6A15B] text-[#C6A15B]'
                          : 'bg-[#10241F] border-[#254d3e] text-[#E9E1D2]/70 hover:text-[#F7F3EA]'
                      }`}
                    >
                      <ThumbsUp className="w-3 h-3" />
                      <span>Helpful ({rev.helpfulCount})</span>
                    </button>

                    {rev.reported && (
                      <span className="text-[10px] text-amber-400">Under Moderation</span>
                    )}
                  </div>
                </div>
              );
            })
          ) : (
            <p className="text-xs text-[#E9E1D2]/60 py-4 text-center">
              No reviews yet for this title. Be the first reader to share your thoughts!
            </p>
          )}
        </div>
      </div>

      {/* Related Books Section */}
      {relatedBooks.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-serif text-xl font-bold text-[#F7F3EA]">
            Readers Also Enjoyed
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {relatedBooks.map((b) => (
              <BookCard key={b.id} book={b} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
