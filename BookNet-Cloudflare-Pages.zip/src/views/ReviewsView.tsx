import React, { useState } from 'react';
import {
  Star,
  ThumbsUp,
  AlertTriangle,
  BookOpen,
  Filter,
  Search,
  MessageSquare,
  Trash2,
  ExternalLink,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ReviewsView: React.FC = () => {
  const {
    reviews,
    toggleHelpfulReview,
    reportReview,
    deleteReview,
    currentUser,
    setSelectedBookId,
    setActivePage,
  } = useApp();

  const [ratingFilter, setRatingFilter] = useState<number | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredReviews = reviews.filter((rev) => {
    const matchesRating = ratingFilter === 'all' || rev.rating === ratingFilter;
    const matchesQuery =
      !searchQuery.trim() ||
      rev.bookTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rev.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rev.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rev.userName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesRating && matchesQuery;
  });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="font-serif text-3xl font-bold text-[#F7F3EA] mb-1">
          Community Book Reviews
        </h1>
        <p className="text-xs text-[#E9E1D2]/70">
          Honest opinions, deep literary analyses, and recommendations from BookNet readers.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#E9E1D2]/50" />
          <input
            type="text"
            placeholder="Search reviews by title, book name, or reviewer..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-[#173D30]/40 border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] placeholder-[#E9E1D2]/40 outline-hidden focus:border-[#C6A15B]"
          />
        </div>

        {/* Rating Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setRatingFilter('all')}
            className={`px-3 py-2 rounded-xl text-xs font-semibold shrink-0 cursor-pointer transition-colors ${
              ratingFilter === 'all'
                ? 'bg-[#C6A15B] text-[#10241F]'
                : 'bg-[#10241F] border border-[#254d3e] text-[#E9E1D2]'
            }`}
          >
            All Ratings
          </button>
          {[5, 4, 3, 2, 1].map((r) => (
            <button
              key={r}
              onClick={() => setRatingFilter(r)}
              className={`flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-semibold shrink-0 cursor-pointer transition-colors ${
                ratingFilter === r
                  ? 'bg-[#C6A15B] text-[#10241F]'
                  : 'bg-[#10241F] border border-[#254d3e] text-[#E9E1D2]'
              }`}
            >
              <span>{r}</span>
              <Star className="w-3 h-3 fill-current" />
            </button>
          ))}
        </div>
      </div>

      {/* Reviews Feed */}
      <div className="space-y-4">
        {filteredReviews.length > 0 ? (
          filteredReviews.map((rev) => {
            const isAuthor = currentUser?.id === rev.userId;
            const hasLiked = currentUser && rev.helpfulUserIds?.includes(currentUser.id);

            return (
              <div
                key={rev.id}
                className="p-5 sm:p-6 rounded-2xl bg-[#173D30]/40 border border-[#254d3e] hover:border-[#C6A15B]/40 transition-all space-y-4"
              >
                {/* Book & Reviewer Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#254d3e]/60 pb-3">
                  <div
                    onClick={() => {
                      setSelectedBookId(rev.bookId);
                      setActivePage('book-detail');
                    }}
                    className="flex items-center gap-3 cursor-pointer group"
                  >
                    <img
                      src={rev.bookCover}
                      alt={rev.bookTitle}
                      className="w-10 h-14 object-cover rounded-md border border-[#254d3e] shadow-xs group-hover:scale-105 transition-transform shrink-0"
                    />
                    <div>
                      <span className="text-[10px] text-[#C6A15B] font-semibold uppercase tracking-wider block">
                        Review for
                      </span>
                      <h4 className="font-serif font-bold text-sm text-[#F7F3EA] group-hover:text-[#C6A15B] transition-colors">
                        {rev.bookTitle}
                      </h4>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <img
                      src={rev.userAvatar}
                      alt={rev.userName}
                      className="w-7 h-7 rounded-full object-cover border border-[#C6A15B]/40"
                    />
                    <div className="text-right sm:text-left">
                      <p className="text-xs font-semibold text-[#F7F3EA]">{rev.userName}</p>
                      <span className="text-[10px] text-[#E9E1D2]/50">
                        {new Date(rev.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Rating & Review Content */}
                <div>
                  <div className="flex items-center gap-1 text-[#C6A15B] mb-2">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star
                        key={s}
                        className={`w-3.5 h-3.5 ${
                          s <= rev.rating
                            ? 'fill-[#C6A15B] text-[#C6A15B]'
                            : 'text-[#E9E1D2]/20'
                        }`}
                      />
                    ))}
                    <span className="text-xs font-bold text-[#F7F3EA] ml-1.5">
                      {rev.rating}.0
                    </span>
                  </div>

                  <h3 className="font-serif font-bold text-base text-[#F7F3EA] mb-1.5">
                    {rev.title}
                  </h3>

                  {rev.containsSpoilers && (
                    <span className="inline-block px-2.5 py-0.5 rounded-sm bg-amber-950/70 border border-amber-800 text-[10px] text-amber-300 mb-2">
                      Spoiler Alert
                    </span>
                  )}

                  <p className="text-xs text-[#E9E1D2]/80 leading-relaxed">
                    {rev.content}
                  </p>
                </div>

                {/* Footer Controls: Helpful & Moderation */}
                <div className="pt-3 border-t border-[#254d3e]/50 flex items-center justify-between text-xs">
                  <button
                    onClick={() => toggleHelpfulReview(rev.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs transition-colors cursor-pointer ${
                      hasLiked
                        ? 'bg-[#C6A15B]/20 border-[#C6A15B] text-[#C6A15B]'
                        : 'bg-[#10241F] border-[#254d3e] text-[#E9E1D2]/70 hover:text-[#F7F3EA]'
                    }`}
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                    <span>Helpful ({rev.helpfulCount})</span>
                  </button>

                  <div className="flex items-center gap-2">
                    {isAuthor && (
                      <button
                        onClick={() => deleteReview(rev.id)}
                        className="p-1.5 text-rose-400 hover:bg-rose-950/40 rounded-lg cursor-pointer"
                        title="Delete your review"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => reportReview(rev.id)}
                      className="p-1.5 text-[#E9E1D2]/40 hover:text-amber-400 rounded-lg cursor-pointer"
                      title="Report for moderation"
                    >
                      <AlertTriangle className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-16 bg-[#173D30]/20 border border-[#254d3e] rounded-2xl p-6">
            <MessageSquare className="w-8 h-8 text-[#E9E1D2]/40 mx-auto mb-2" />
            <p className="text-xs text-[#E9E1D2]/70">No reviews found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
};
