import React, { useState } from 'react';
import {
  Shield,
  FileText,
  HelpCircle,
  Mail,
  ChevronDown,
  Send,
  CheckCircle2,
  BookOpen,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const PrivacyPolicyView: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C6A15B]">
          Legal & Trust
        </span>
        <h1 className="font-serif text-3xl font-bold text-[#F7F3EA] mb-2">
          Privacy Policy
        </h1>
        <p className="text-xs text-[#E9E1D2]/70">Effective Date: January 1, 2026</p>
      </div>

      <div className="p-8 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] text-xs text-[#E9E1D2]/90 leading-relaxed space-y-4 shadow-xl">
        <h2 className="font-serif text-base font-bold text-[#F7F3EA]">1. Introduction</h2>
        <p>
          At BookNet (&ldquo;we&rdquo;, &ldquo;our&rdquo;, or &ldquo;us&rdquo;), we believe reading is an intimate, personal, and transformative journey. We are dedicated to respecting your privacy, protecting your reading history, and ensuring you retain absolute ownership over your notes and reviews.
        </p>

        <h2 className="font-serif text-base font-bold text-[#F7F3EA]">2. Information We Collect</h2>
        <p>
          BookNet stores information you explicitly provide: your display name, username, email address, personal reading shelves (Want to Read, Currently Reading, Finished), logged page progress, ratings, and written reviews. In prototype mode, this data remains stored securely in your browser&apos;s local storage.
        </p>

        <h2 className="font-serif text-base font-bold text-[#F7F3EA]">3. Third-Party Book Data Sources</h2>
        <p>
          To facilitate title discovery, BookNet interacts with the non-profit Open Library API and legitimate public-domain literature providers (such as Standard Ebooks and Project Gutenberg). We do not transmit your private reading lists to third parties without your explicit command.
        </p>

        <h2 className="font-serif text-base font-bold text-[#F7F3EA]">4. Data Portability & Rights</h2>
        <p>
          You retain the right to export your entire library, annotations, and reading statistics at any time via the Settings page in open JSON format, or reset your local prototype data.
        </p>

        <h2 className="font-serif text-base font-bold text-[#F7F3EA]">5. Contact Us</h2>
        <p>
          If you have questions regarding this privacy policy or our data practices, contact us at <code>privacy@booknet.org</code>.
        </p>
      </div>
    </div>
  );
};

export const TermsOfServiceView: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C6A15B]">
          Community Guidelines
        </span>
        <h1 className="font-serif text-3xl font-bold text-[#F7F3EA] mb-2">
          Terms of Service
        </h1>
        <p className="text-xs text-[#E9E1D2]/70">Last Updated: January 1, 2026</p>
      </div>

      <div className="p-8 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] text-xs text-[#E9E1D2]/90 leading-relaxed space-y-4 shadow-xl">
        <h2 className="font-serif text-base font-bold text-[#F7F3EA]">1. Acceptance of Terms</h2>
        <p>
          By creating an account, browsing books, or participating in BookNet community discussions, you agree to abide by these Terms of Service and our Community Guidelines.
        </p>

        <h2 className="font-serif text-base font-bold text-[#F7F3EA]">2. Community Conduct & Reviews</h2>
        <p>
          BookNet is a sanctuary for thoughtful civil discourse, literary exploration, and encouragement. Harassment, hate speech, spam, defamatory content, and unsolicited promotional campaigns are strictly prohibited. Reviews containing plot developments must be marked with the &ldquo;Spoiler Alert&rdquo; flag to preserve the discovery experience for fellow readers.
        </p>

        <h2 className="font-serif text-base font-bold text-[#F7F3EA]">3. Intellectual Property</h2>
        <p>
          All reviews, comments, and lists created by you remain your intellectual property. Book covers, book descriptions, and metadata referenced on BookNet are attributed to their respective authors, publishers, or public repositories (Open Library, Standard Ebooks, Project Gutenberg).
        </p>

        <h2 className="font-serif text-base font-bold text-[#F7F3EA]">4. Disclaimers</h2>
        <p>
          BookNet provides cataloging and community tracking services &ldquo;as is&rdquo;. We do not distribute pirated or unauthorized digital files of copyrighted books.
        </p>
      </div>
    </div>
  );
};

export const ContactHelpView: React.FC = () => {
  const { showToast } = useApp();
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const faqs = [
    {
      q: 'How does BookNet track my reading progress?',
      a: 'You can update your current page number or completion percentage directly from any book detail page, your personal library, or the Quick Session Logger in your Reading Dashboard. BookNet automatically calculates your pace and updates your annual reading challenge.',
    },
    {
      q: 'Where do the book search results and covers come from?',
      a: 'BookNet integrates live with the Open Library API (an open catalog by the Internet Archive) and pairs it with our curated editorial recommendations to ensure rich descriptions, verified publication years, and authentic ISBN metadata.',
    },
    {
      q: 'Can I read books directly on BookNet?',
      a: 'For public domain classics (like Pride and Prejudice, Meditations, or The Great Gatsby), BookNet provides direct verified links to read free on Standard Ebooks and Project Gutenberg. For modern copyright titles, we link directly to Open Library lending and verified publisher overviews.',
    },
    {
      q: 'Is my data preserved between sessions?',
      a: 'Yes! All your shelves, ratings, written reviews, and custom lists persist across visits in your browser storage. You can also export a complete JSON backup at any time in the Settings view.',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !message) {
      showToast('Please complete all contact form fields');
      return;
    }
    setSubmitted(true);
    showToast('Your message has been sent to the BookNet team!');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      <div>
        <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C6A15B]">
          Support & Assistance
        </span>
        <h1 className="font-serif text-3xl font-bold text-[#F7F3EA] mb-2">
          Contact & Help Center
        </h1>
        <p className="text-xs text-[#E9E1D2]/70">
          Find answers to common questions or reach out directly to the BookNet team.
        </p>
      </div>

      {/* FAQ Accordion */}
      <div className="space-y-3">
        <h2 className="font-serif text-xl font-bold text-[#F7F3EA] flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-[#C6A15B]" />
          <span>Frequently Asked Questions</span>
        </h2>

        <div className="space-y-2">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl bg-[#173D30]/60 border border-[#254d3e] overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full p-4 flex items-center justify-between text-left text-xs font-semibold text-[#F7F3EA] hover:text-[#C6A15B] cursor-pointer"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-[#C6A15B] transition-transform ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 pt-1 text-xs text-[#E9E1D2]/80 leading-relaxed border-t border-[#254d3e]/40">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Contact Form */}
      <div className="p-8 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] shadow-xl space-y-6">
        <div>
          <h2 className="font-serif text-xl font-bold text-[#F7F3EA] flex items-center gap-2">
            <Mail className="w-5 h-5 text-[#C6A15B]" />
            <span>Send Us an Inquiry</span>
          </h2>
          <p className="text-xs text-[#E9E1D2]/70 mt-1">
            Have a suggestion, feature request, or need help with your account? We usually respond within 24 hours.
          </p>
        </div>

        {submitted ? (
          <div className="p-6 rounded-2xl bg-emerald-950/80 border border-emerald-600/50 text-emerald-300 text-xs flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>Thank you, {name}! We have received your inquiry and will be in touch shortly.</span>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium text-[#E9E1D2]/80 block mb-1">
                  Your Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Leo Tolstoy"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-[#E9E1D2]/80 block mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-[#E9E1D2]/80 block mb-1">
                Your Message
              </label>
              <textarea
                rows={4}
                placeholder="How can we assist your reading journey?"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full p-3 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B] leading-relaxed"
              />
            </div>

            <button
              type="submit"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Message</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
