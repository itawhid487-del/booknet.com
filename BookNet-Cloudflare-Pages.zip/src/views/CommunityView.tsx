import React, { useState } from 'react';
import {
  Users,
  MessageSquare,
  ThumbsUp,
  Award,
  Plus,
  Send,
  Sparkles,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Discussion } from '../types/index';

export const CommunityView: React.FC = () => {
  const {
    discussions,
    addDiscussion,
    addReply,
    likeDiscussion,
    challenges,
    toggleJoinChallenge,
    currentUser,
    showToast,
  } = useApp();

  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [selectedDiscussionId, setSelectedDiscussionId] = useState<string | null>(
    discussions[0]?.id || null
  );
  const [replyInput, setReplyInput] = useState('');

  // Create thread modal
  const [isCreatingThread, setIsCreatingThread] = useState(false);
  const [threadTitle, setThreadTitle] = useState('');
  const [threadContent, setThreadContent] = useState('');
  const [threadCategory, setThreadCategory] = useState<Discussion['category']>('Book Club');

  const categories = ['All', 'Book Club', 'Recommendations', 'General Chat', 'Reading Challenges'];

  const filteredDiscussions =
    activeCategory === 'All'
      ? discussions
      : discussions.filter((d) => d.category === activeCategory);

  const selectedDiscussion =
    discussions.find((d) => d.id === selectedDiscussionId) || filteredDiscussions[0];

  const handlePostReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyInput.trim() || !selectedDiscussion) return;
    addReply(selectedDiscussion.id, replyInput);
    setReplyInput('');
  };

  const handleCreateThread = (e: React.FormEvent) => {
    e.preventDefault();
    if (!threadTitle.trim() || !threadContent.trim()) {
      showToast('Please provide both a topic title and body');
      return;
    }
    addDiscussion(threadTitle, threadContent, threadCategory);
    setThreadTitle('');
    setThreadContent('');
    setIsCreatingThread(false);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold text-[#F7F3EA] mb-1">
            Reading Community
          </h1>
          <p className="text-xs text-[#E9E1D2]/70">
            Join book clubs, exchange recommendations, and participate in reading challenges.
          </p>
        </div>

        <button
          onClick={() => setIsCreatingThread(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs transition-colors self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Start a Discussion</span>
        </button>
      </div>

      {/* Reading Challenges Cards */}
      <div className="space-y-3">
        <h2 className="font-serif text-lg font-bold text-[#F7F3EA] flex items-center gap-2">
          <Award className="w-5 h-5 text-[#C6A15B]" />
          <span>Active Community Challenges</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {challenges.map((chal) => (
            <div
              key={chal.id}
              className="p-5 rounded-2xl bg-[#173D30]/60 border border-[#254d3e] shadow-lg flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-[#C6A15B]">
                    Target: {chal.targetBooks} Books
                  </span>
                  <span className="text-[11px] text-[#E9E1D2]/60">
                    {chal.participantCount.toLocaleString()} readers
                  </span>
                </div>
                <h3 className="font-serif font-bold text-base text-[#F7F3EA] mb-1">
                  {chal.title}
                </h3>
                <p className="text-xs text-[#E9E1D2]/70 leading-relaxed mb-4">
                  {chal.description}
                </p>
              </div>

              <div className="pt-3 border-t border-[#254d3e]/50 flex items-center justify-between">
                <span className="text-[10px] text-[#E9E1D2]/50">Ends {chal.endDate}</span>
                <button
                  onClick={() => toggleJoinChallenge(chal.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    chal.joined
                      ? 'bg-emerald-950/80 border border-emerald-500/60 text-emerald-300'
                      : 'bg-[#C6A15B] text-[#10241F] hover:bg-[#d6b16b]'
                  }`}
                >
                  {chal.joined ? 'Joined ✓' : 'Join Challenge'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Discussion Forum Layout */}
      <div className="space-y-4 pt-4 border-t border-[#173D30]">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-lg font-bold text-[#F7F3EA] flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-[#C6A15B]" />
            <span>Community Discussions</span>
          </h2>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1 rounded-full text-xs font-medium shrink-0 transition-colors cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-[#C6A15B] text-[#10241F] font-bold'
                    : 'bg-[#10241F] text-[#E9E1D2]/70 hover:text-[#F7F3EA] border border-[#254d3e]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* 2-Column Forum: Threads on left, Thread & replies on right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Thread List */}
          <div className="lg:col-span-5 space-y-3">
            {filteredDiscussions.map((d) => {
              const isSelected = selectedDiscussion?.id === d.id;
              return (
                <div
                  key={d.id}
                  onClick={() => setSelectedDiscussionId(d.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#173D30] border-[#C6A15B] shadow-lg ring-1 ring-[#C6A15B]/40'
                      : 'bg-[#173D30]/40 border-[#254d3e] hover:bg-[#173D30]/70'
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px] text-[#E9E1D2]/60 mb-1.5">
                    <span className="px-2 py-0.5 rounded-full bg-[#10241F] text-[10px] text-[#C6A15B] font-medium">
                      {d.category}
                    </span>
                    <span>{new Date(d.createdAt).toLocaleDateString()}</span>
                  </div>

                  <h3 className="font-serif font-bold text-sm text-[#F7F3EA] mb-1 line-clamp-2">
                    {d.title}
                  </h3>
                  <p className="text-xs text-[#E9E1D2]/70 line-clamp-2 leading-relaxed mb-3">
                    {d.content}
                  </p>

                  <div className="flex items-center justify-between text-xs text-[#E9E1D2]/60 pt-2 border-t border-[#254d3e]/50">
                    <div className="flex items-center gap-2">
                      <img
                        src={d.authorAvatar}
                        alt={d.authorName}
                        className="w-5 h-5 rounded-full object-cover"
                      />
                      <span>{d.authorName}</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1">
                        <MessageSquare className="w-3.5 h-3.5" />
                        {d.repliesCount}
                      </span>
                      <span className="flex items-center gap-1 text-[#C6A15B]">
                        <ThumbsUp className="w-3.5 h-3.5" />
                        {d.likesCount}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Active Thread Detail & Replies */}
          <div className="lg:col-span-7">
            {selectedDiscussion ? (
              <div className="p-6 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] shadow-xl space-y-6">
                {/* Thread Header */}
                <div className="space-y-3 border-b border-[#254d3e] pb-4">
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full bg-[#10241F] border border-[#254d3e] text-xs font-semibold text-[#C6A15B]">
                      {selectedDiscussion.category}
                    </span>
                    <button
                      onClick={() => likeDiscussion(selectedDiscussion.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs transition-colors cursor-pointer ${
                        selectedDiscussion.likedByUser
                          ? 'bg-[#C6A15B]/20 border-[#C6A15B] text-[#C6A15B]'
                          : 'bg-[#10241F] border-[#254d3e] text-[#E9E1D2]/70 hover:text-[#F7F3EA]'
                      }`}
                    >
                      <ThumbsUp className="w-3.5 h-3.5" />
                      <span>{selectedDiscussion.likesCount} Likes</span>
                    </button>
                  </div>

                  <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#F7F3EA]">
                    {selectedDiscussion.title}
                  </h2>

                  <div className="flex items-center gap-3 text-xs text-[#E9E1D2]/70">
                    <img
                      src={selectedDiscussion.authorAvatar}
                      alt={selectedDiscussion.authorName}
                      className="w-7 h-7 rounded-full object-cover border border-[#C6A15B]/40"
                    />
                    <div>
                      <span className="font-semibold text-[#F7F3EA]">
                        {selectedDiscussion.authorName}
                      </span>
                      <span className="text-[#E9E1D2]/50 ml-2">
                        {new Date(selectedDiscussion.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  <p className="text-sm text-[#E9E1D2]/90 leading-relaxed pt-2">
                    {selectedDiscussion.content}
                  </p>
                </div>

                {/* Replies Thread */}
                <div className="space-y-4">
                  <h4 className="font-serif font-bold text-sm text-[#F7F3EA]">
                    Discussion Replies ({selectedDiscussion.replies.length})
                  </h4>

                  <div className="space-y-3">
                    {selectedDiscussion.replies.map((rep) => (
                      <div
                        key={rep.id}
                        className="p-4 rounded-2xl bg-[#10241F]/60 border border-[#254d3e] space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={rep.authorAvatar}
                              alt={rep.authorName}
                              className="w-6 h-6 rounded-full object-cover"
                            />
                            <span className="text-xs font-semibold text-[#F7F3EA]">
                              {rep.authorName}
                            </span>
                          </div>
                          <span className="text-[10px] text-[#E9E1D2]/50">
                            {new Date(rep.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-xs text-[#E9E1D2]/80 leading-relaxed pl-8">
                          {rep.content}
                        </p>
                      </div>
                    ))}
                  </div>

                  {/* Post a Reply Input */}
                  <form onSubmit={handlePostReply} className="pt-2 flex gap-2">
                    <input
                      type="text"
                      placeholder="Share your perspective on this topic..."
                      value={replyInput}
                      onChange={(e) => setReplyInput(e.target.value)}
                      className="flex-1 px-4 py-2.5 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2.5 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Reply</span>
                    </button>
                  </form>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-xs text-[#E9E1D2]/60">
                Select a discussion from the left to read replies.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Create Discussion Thread Modal */}
      {isCreatingThread && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-[#173D30] border border-[#254d3e] rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-5 animate-in zoom-in-95 duration-200">
            <div>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C6A15B]">
                Start a Discussion
              </span>
              <h3 className="font-serif text-xl font-bold text-[#F7F3EA]">
                New Community Topic
              </h3>
            </div>

            <form onSubmit={handleCreateThread} className="space-y-4">
              <div>
                <label className="text-xs font-medium text-[#E9E1D2]/80 block mb-1">
                  Forum Category
                </label>
                <select
                  value={threadCategory}
                  onChange={(e) => setThreadCategory(e.target.value as Discussion['category'])}
                  className="w-full p-2.5 bg-[#10241F] border border-[#254d3e] text-xs text-[#F7F3EA] rounded-xl outline-hidden focus:border-[#C6A15B]"
                >
                  <option value="Book Club">Book Club</option>
                  <option value="Recommendations">Recommendations</option>
                  <option value="General Chat">General Chat</option>
                  <option value="Reading Challenges">Reading Challenges</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-[#E9E1D2]/80 block mb-1">
                  Topic Title
                </label>
                <input
                  type="text"
                  placeholder="e.g. Which chapter of Dune surprised you most?"
                  value={threadTitle}
                  onChange={(e) => setThreadTitle(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#10241F] border border-[#254d3e] text-xs text-[#F7F3EA] rounded-xl outline-hidden focus:border-[#C6A15B]"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-[#E9E1D2]/80 block mb-1">
                  Topic Details & Discussion Prompt
                </label>
                <textarea
                  rows={4}
                  placeholder="Share your thoughts and questions to kick off the thread..."
                  value={threadContent}
                  onChange={(e) => setThreadContent(e.target.value)}
                  className="w-full p-3 bg-[#10241F] border border-[#254d3e] text-xs text-[#F7F3EA] rounded-xl outline-hidden focus:border-[#C6A15B] leading-relaxed"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreatingThread(false)}
                  className="px-4 py-2 rounded-xl bg-[#10241F] text-xs font-medium text-[#E9E1D2] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs cursor-pointer"
                >
                  Publish Topic
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
