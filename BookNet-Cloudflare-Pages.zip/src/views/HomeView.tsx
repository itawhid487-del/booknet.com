import React, { useState } from 'react';
import {
  ArrowRight,
  BookOpen,
  Lightbulb,
  Sparkles,
  Search,
  Compass,
  Heart,
  Landmark,
  Sprout,
  Coins,
  Send,
  Star,
  CheckCircle,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { INITIAL_BOOKS } from '../services/booksData';
import { BookCard } from '../components/BookCard';

export const HomeView: React.FC = () => {
  const { setActivePage, setSelectedGenre } = useApp();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);
  const [newsletterError, setNewsletterError] = useState('');

  // Featured books (first 6)
  const featuredBooks = INITIAL_BOOKS.slice(0, 6);
  // New Arrivals (books 6 to 12)
  const newArrivals = INITIAL_BOOKS.slice(6, 12);

  const genres = [
    { name: 'Fiction', id: 'fiction', icon: BookOpen, color: 'text-emerald-400 bg-emerald-950/50' },
    { name: 'Non-Fiction', id: 'non-fiction', icon: Lightbulb, color: 'text-amber-400 bg-amber-950/50' },
    { name: 'Fantasy', id: 'fantasy', icon: Sparkles, color: 'text-purple-400 bg-purple-950/50' },
    { name: 'Mystery', id: 'mystery', icon: Search, color: 'text-sky-400 bg-sky-950/50' },
    { name: 'Sci-Fi', id: 'sci-fi', icon: Compass, color: 'text-cyan-400 bg-cyan-950/50' },
    { name: 'Romance', id: 'romance', icon: Heart, color: 'text-rose-400 bg-rose-950/50' },
    { name: 'Classics', id: 'classics', icon: Landmark, color: 'text-indigo-400 bg-indigo-950/50' },
    { name: 'Self-Help', id: 'self-help', icon: Sprout, color: 'text-emerald-400 bg-emerald-950/50' },
    { name: 'Finance', id: 'finance', icon: Coins, color: 'text-yellow-400 bg-yellow-950/50' },
  ];

  const handleGenreClick = (genreId: string) => {
    setSelectedGenre(genreId);
    setActivePage('discover');
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes('@') || !newsletterEmail.includes('.')) {
      setNewsletterError('Please enter a valid email address');
      return;
    }
    setNewsletterError('');
    setNewsletterSubscribed(true);
  };

  return (
    <div className="space-y-10">
      {/* Hero Banner (matches user's reference layout) */}
      <section className="relative rounded-3xl overflow-hidden border border-[#254d3e] shadow-2xl bg-[#173D30]/60">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-center min-h-[380px]">
          {/* Left Text Column */}
          <div className="lg:col-span-6 p-7 md:p-10 lg:p-12 z-10 flex flex-col justify-center">
            <span className="text-xs font-semibold uppercase tracking-widest text-[#C6A15B] mb-2 block">
              WELCOME TO BOOKNET
            </span>
            <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#F7F3EA] leading-tight mb-4">
              More Books. <br className="hidden sm:inline" />
              Bigger Dreams.
            </h1>
            <p className="text-sm sm:text-base text-[#E9E1D2]/80 leading-relaxed mb-6 max-w-lg">
              Discover new worlds, meet unforgettable characters, and be part of a community that loves to read.
            </p>
            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={() => setActivePage('discover')}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-sm shadow-lg hover:shadow-xl transition-all cursor-pointer transform hover:-translate-y-0.5"
              >
                <span>Explore Books</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => setActivePage('library')}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-[#10241F]/80 hover:bg-[#10241F] text-[#F7F3EA] border border-[#254d3e] font-medium text-sm transition-all cursor-pointer"
              >
                <span>Build Your Library</span>
              </button>
            </div>
          </div>

          {/* Right Visual Image Column */}
          <div className="lg:col-span-6 h-64 lg:h-full relative overflow-hidden flex items-center justify-center">
            <img
              src="https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=1200"
              alt="Cozy reading space with books, mug and mountain view"
              className="w-full h-full object-cover object-center lg:absolute lg:inset-0 opacity-90"
            />
            {/* Soft gradient mask for smooth blend */}
            <div className="absolute inset-0 bg-linear-to-t lg:bg-linear-to-r from-[#173D30] via-transparent to-transparent pointer-events-none" />
            <div className="absolute bottom-4 right-4 bg-[#10241F]/80 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-[#254d3e] text-[11px] text-[#E9E1D2]/80 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Over 10,000+ curated volumes</span>
            </div>
          </div>
        </div>
      </section>

      {/* Explore by Genre Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold uppercase tracking-widest text-[#E9E1D2]/60 block">
              EXPLORE BY GENRE
            </span>
            <h2 className="font-serif text-xl font-bold text-[#F7F3EA]">Browse Categories</h2>
          </div>
          <button
            onClick={() => setActivePage('discover')}
            className="text-xs font-semibold text-[#C6A15B] hover:text-[#d6b16b] flex items-center gap-1 cursor-pointer transition-colors"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Category Pills/Cards Row */}
        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-9 gap-3">
          {genres.map((g) => {
            const Icon = g.icon;
            return (
              <button
                key={g.id}
                onClick={() => handleGenreClick(g.id)}
                className="flex flex-col items-center justify-center p-3 rounded-2xl bg-[#173D30]/40 hover:bg-[#173D30] border border-[#254d3e]/70 hover:border-[#C6A15B]/50 transition-all duration-200 group cursor-pointer"
              >
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center mb-2 border border-[#254d3e] group-hover:scale-110 transition-transform ${g.color}`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-xs font-medium text-[#F7F3EA] group-hover:text-[#C6A15B] transition-colors text-center">
                  {g.name}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Featured Books Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-[#C6A15B] fill-[#C6A15B]" />
            <h2 className="font-serif text-xl font-bold text-[#F7F3EA]">Featured Books</h2>
          </div>
          <button
            onClick={() => setActivePage('discover')}
            className="text-xs font-semibold text-[#C6A15B] hover:text-[#d6b16b] flex items-center gap-1 cursor-pointer transition-colors"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {featuredBooks.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      </section>

      {/* New Arrivals Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sprout className="w-5 h-5 text-emerald-400" />
            <h2 className="font-serif text-xl font-bold text-[#F7F3EA]">New Arrivals</h2>
          </div>
          <button
            onClick={() => setActivePage('discover')}
            className="text-xs font-semibold text-[#C6A15B] hover:text-[#d6b16b] flex items-center gap-1 cursor-pointer transition-colors"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {newArrivals.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      </section>

      {/* Reading Newsletter Section */}
      <section className="p-8 rounded-3xl bg-linear-to-r from-[#173D30] to-[#0c1a16] border border-[#254d3e] text-center max-w-3xl mx-auto shadow-xl">
        <div className="w-12 h-12 rounded-2xl bg-[#10241F] border border-[#C6A15B]/30 flex items-center justify-center text-[#C6A15B] mx-auto mb-4">
          <BookOpen className="w-6 h-6" />
        </div>
        <h3 className="font-serif text-2xl font-bold text-[#F7F3EA] mb-2">
          Weekly Bookish Delights Delivered
        </h3>
        <p className="text-sm text-[#E9E1D2]/80 max-w-md mx-auto mb-6">
          Hand-picked recommendations, literary essays, reading challenges, and indie book spotlights every Sunday.
        </p>

        {newsletterSubscribed ? (
          <div className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-emerald-950/80 border border-emerald-600/50 text-emerald-300 text-sm font-medium animate-in fade-in">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span>Thank you for subscribing! Check your inbox this Sunday.</span>
          </div>
        ) : (
          <form onSubmit={handleNewsletterSubmit} className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="email"
                placeholder="Enter your email address..."
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                className="flex-1 px-4 py-3 rounded-full bg-[#10241F] border border-[#254d3e] text-sm text-[#F7F3EA] placeholder-[#E9E1D2]/40 outline-hidden focus:border-[#C6A15B]"
              />
              <button
                type="submit"
                className="px-6 py-3 rounded-full bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer shrink-0"
              >
                <span>Subscribe</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
            {newsletterError && (
              <p className="text-xs text-rose-400 mt-2">{newsletterError}</p>
            )}
          </form>
        )}
      </section>
    </div>
  );
};
