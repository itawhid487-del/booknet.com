import React, { useState } from 'react';
import {
  Settings,
  Database,
  Download,
  Upload,
  RefreshCw,
  Bell,
  Palette,
  Shield,
  HelpCircle,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const SettingsView: React.FC = () => {
  const {
    currentUser,
    updateProfile,
    resetToSampleData,
    exportDataJson,
    importDataJson,
    showToast,
  } = useApp();

  const [importJsonText, setImportJsonText] = useState('');
  const [showImportArea, setShowImportArea] = useState(false);
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [weeklyDigest, setWeeklyDigest] = useState(true);

  const handleExport = () => {
    const jsonStr = exportDataJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `booknet_library_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    showToast('BookNet library data downloaded as JSON backup.');
  };

  const handleImportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!importJsonText.trim()) return;
    const success = importDataJson(importJsonText);
    if (success) {
      setImportJsonText('');
      setShowImportArea(false);
    }
  };

  return (
    <div className="space-y-8 max-w-4xl">
      <div>
        <h1 className="font-serif text-3xl font-bold text-[#F7F3EA] mb-1">
          Settings & Data Management
        </h1>
        <p className="text-xs text-[#E9E1D2]/70">
          Manage your personal reading preferences, database backup, and prototype environment.
        </p>
      </div>

      {/* Production Backend / Architecture Notice (Strict requirement from brief) */}
      <div className="p-6 rounded-3xl bg-[#173D30]/80 border border-[#C6A15B]/50 shadow-xl space-y-3">
        <div className="flex items-center gap-2.5 text-[#C6A15B]">
          <Database className="w-5 h-5 shrink-0" />
          <h2 className="font-serif font-bold text-base text-[#F7F3EA]">
            Data Architecture & Prototype Status
          </h2>
        </div>

        <p className="text-xs text-[#E9E1D2]/90 leading-relaxed">
          BookNet is currently running in a fully functional <strong>Single-Device Local Prototype Mode</strong> backed by persistent browser LocalStorage and Open Library live APIs. Your personal library shelves, reading goals, custom lists, review logs, and reading sessions persist seamlessly across browser reloads on this machine.
        </p>

        <div className="p-4 rounded-2xl bg-[#10241F]/80 border border-[#254d3e] text-xs space-y-2">
          <p className="font-semibold text-[#F7F3EA]">
            Requirements for Cross-Device Production Deployment:
          </p>
          <ul className="list-disc pl-5 space-y-1 text-[#E9E1D2]/80">
            <li>
              <strong>Database Backend:</strong> Connect a PostgreSQL / Cloud SQL or Supabase instance with schemas for <code>users</code>, <code>library_books</code>, <code>reading_sessions</code>, <code>reading_lists</code>, and <code>reviews</code>.
            </li>
            <li>
              <strong>Authentication Service:</strong> Enable Firebase Authentication or OAuth 2.0 with session cookies / JWT authorization tokens.
            </li>
            <li>
              <strong>Edge CDN / Hosting:</strong> Deployed via standard Vite build output (<code>dist/</code>) to Cloudflare Pages or Cloud Run.
            </li>
          </ul>
        </div>
      </div>

      {/* Backup and Portability */}
      <div className="p-6 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] shadow-xl space-y-5">
        <div className="flex items-center gap-2">
          <Download className="w-5 h-5 text-[#C6A15B]" />
          <h2 className="font-serif font-bold text-lg text-[#F7F3EA]">
            Data Backup & Portability
          </h2>
        </div>
        <p className="text-xs text-[#E9E1D2]/70">
          Export your complete reading history and reviews as an open JSON file, or restore from a previous backup.
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export Library JSON</span>
          </button>

          <button
            onClick={() => setShowImportArea(!showImportArea)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#10241F] border border-[#254d3e] hover:border-[#C6A15B] text-xs font-semibold text-[#F7F3EA] transition-colors cursor-pointer"
          >
            <Upload className="w-4 h-4 text-[#C6A15B]" />
            <span>Import from JSON</span>
          </button>

          <button
            onClick={resetToSampleData}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#10241F] border border-[#254d3e] hover:border-amber-400 text-xs font-semibold text-amber-300 transition-colors cursor-pointer ml-auto"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Reset Demo Data</span>
          </button>
        </div>

        {showImportArea && (
          <form onSubmit={handleImportSubmit} className="pt-3 space-y-3">
            <label className="text-xs text-[#E9E1D2]/80 block">
              Paste JSON Export Content:
            </label>
            <textarea
              rows={4}
              value={importJsonText}
              onChange={(e) => setImportJsonText(e.target.value)}
              placeholder="Paste your exported BookNet JSON backup here..."
              className="w-full p-3 font-mono text-xs bg-[#10241F] border border-[#254d3e] rounded-xl text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
            />
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#C6A15B] text-[#10241F] font-bold text-xs cursor-pointer"
            >
              Confirm Import
            </button>
          </form>
        )}
      </div>

      {/* Notifications Settings */}
      <div className="p-6 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] shadow-xl space-y-4">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-[#C6A15B]" />
          <h2 className="font-serif font-bold text-lg text-[#F7F3EA]">
            Notification Preferences
          </h2>
        </div>

        <div className="space-y-3">
          <label className="flex items-center justify-between p-3 rounded-xl bg-[#10241F]/60 border border-[#254d3e] cursor-pointer">
            <div>
              <p className="text-xs font-semibold text-[#F7F3EA]">Reading Reminders</p>
              <p className="text-[11px] text-[#E9E1D2]/60">Daily nudge to keep your reading streak alive</p>
            </div>
            <input
              type="checkbox"
              checked={emailNotifs}
              onChange={(e) => setEmailNotifs(e.target.checked)}
              className="accent-[#C6A15B] w-4 h-4"
            />
          </label>

          <label className="flex items-center justify-between p-3 rounded-xl bg-[#10241F]/60 border border-[#254d3e] cursor-pointer">
            <div>
              <p className="text-xs font-semibold text-[#F7F3EA]">Weekly Reading Digest</p>
              <p className="text-[11px] text-[#E9E1D2]/60">Summary of pages read, goal pacing, and community book clubs</p>
            </div>
            <input
              type="checkbox"
              checked={weeklyDigest}
              onChange={(e) => setWeeklyDigest(e.target.checked)}
              className="accent-[#C6A15B] w-4 h-4"
            />
          </label>
        </div>
      </div>
    </div>
  );
};
