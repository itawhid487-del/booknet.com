import React, { useState } from 'react';
import {
  Bookmark,
  BookOpen,
  CheckCircle2,
  Search,
  Filter,
  ArrowUpDown,
  Trash2,
  Edit3,
  Calendar,
  Layers,
  Star,
  Check,
  ChevronRight,
  Plus,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ReadingStatus, LibraryBook } from '../types/index';
import { filterAndSortBooks, calculateProgress } from '../utils/library';

export const LibraryView: React.FC = () => {
  const {
    library,
    removeFromLibrary,
    updateLibraryBook,
    setSelectedBookId,
    setActivePage,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | ReadingStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');
  const [sortBy, setSortBy] = useState('recent');

  // Editing progress modal state
  const [editingBook, setEditingBook] = useState<LibraryBook | null>(null);
  const [editPage, setEditPage] = useState<number>(0);
  const [editStatus, setEditStatus] = useState<ReadingStatus>('currently_reading');
  const [editNotes, setEditNotes] = useState<string>('');

  const filteredBooks = filterAndSortBooks(
    library,
    searchQuery,
    activeTab,
    sortBy,
    selectedGenre
  );

  const counts = {
    all: library.length,
    want_to_read: library.filter((b) => b.status === 'want_to_read').length,
    currently_reading: library.filter((b) => b.status === 'currently_reading').length,
    finished: library.filter((b) => b.status === 'finished').length,
  };

  const openEditModal = (item: LibraryBook) => {
    setEditingBook(item);
    setEditPage(item.currentPage);
    setEditStatus(item.status);
    setEditNotes(item.notes || '');
  };

  const handleSaveEdit = () => {
    if (!editingBook) return;
    const safePage = Math.max(0, Math.min(editingBook.totalPages, editPage));
    const newStatus = safePage >= editingBook.totalPages ? 'finished' : editStatus;
    updateLibraryBook(editingBook.book.id, {
      currentPage: safePage,
      status: newStatus,
      notes: editNotes,
    });
    setEditingBook(null);
    showToast(`Updated "${editingBook.book.title}" in your library`);
  };

  const handleQuickMove = (bookId: string, newStatus: ReadingStatus) => {
    const item = library.find((b) => b.book.id === bookId);
    if (!item) return;
    const newPage = newStatus === 'finished' ? item.totalPages : item.currentPage;
    updateLibraryBook(bookId, {
      status: newStatus,
      currentPage: newPage,
    });
    showToast(`Moved to ${newStatus.replace(/_/g, ' ')}`);
  };

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold text-[#F7F3EA] mb-1">
            My Library
          </h1>
          <p className="text-xs text-[#E9E1D2]/70">
            Manage your personal bookshelves, reading progress, and personal reflections.
          </p>
        </div>

        <button
          onClick={() => setActivePage('discover')}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs transition-colors self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add More Books</span>
        </button>
      </div>

      {/* Reading Status Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-[#173D30]">
        {[
          { id: 'all', label: 'All Shelves', count: counts.all, icon: Layers },
          { id: 'want_to_read', label: 'Want to Read', count: counts.want_to_read, icon: Bookmark },
          { id: 'currently_reading', label: 'Currently Reading', count: counts.currently_reading, icon: BookOpen },
          { id: 'finished', label: 'Finished', count: counts.finished, icon: CheckCircle2 },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-2 px-4 py-3 border-b-2 text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'border-[#C6A15B] text-[#C6A15B] bg-[#173D30]/30'
                  : 'border-transparent text-[#E9E1D2]/70 hover:text-[#F7F3EA] hover:bg-[#173D30]/20'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              <span className="px-2 py-0.5 rounded-full bg-[#10241F] text-[10px] text-[#E9E1D2]/80">
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#E9E1D2]/50" />
          <input
            type="text"
            placeholder="Search within your library (title, author, personal notes)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-[#173D30]/40 border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] placeholder-[#E9E1D2]/40 outline-hidden focus:border-[#C6A15B]"
          />
        </div>

        <div className="flex items-center gap-2">
          {/* Sort */}
          <div className="relative">
            <ArrowUpDown className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#E9E1D2]/50 pointer-events-none" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="pl-8 pr-7 py-2.5 bg-[#173D30]/40 border border-[#254d3e] text-xs font-medium text-[#F7F3EA] rounded-xl outline-hidden focus:border-[#C6A15B] cursor-pointer appearance-none"
            >
              <option value="recent">Recently Updated</option>
              <option value="progress_desc">Highest Progress</option>
              <option value="rating_desc">My Rating</option>
              <option value="title_asc">Title (A - Z)</option>
              <option value="author">Author Name</option>
            </select>
          </div>
        </div>
      </div>

      {/* Books List / Table View */}
      {filteredBooks.length > 0 ? (
        <div className="space-y-4">
          {filteredBooks.map((item) => {
            const percent = calculateProgress(item.currentPage, item.totalPages);
            return (
              <div
                key={item.book.id}
                className="p-4 sm:p-5 rounded-2xl bg-[#173D30]/40 border border-[#254d3e] hover:border-[#C6A15B]/40 transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4 group"
              >
                {/* Book Media & Info */}
                <div
                  onClick={() => {
                    setSelectedBookId(item.book.id);
                    setActivePage('book-detail');
                  }}
                  className="flex items-center gap-4 cursor-pointer flex-1 min-w-0"
                >
                  <img
                    src={item.book.coverUrl}
                    alt={item.book.title}
                    className="w-14 h-20 object-cover rounded-lg shadow-md border border-[#254d3e] shrink-0 group-hover:scale-105 transition-transform"
                  />
                  <div className="min-w-0 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2 py-0.5 rounded-full bg-[#10241F] text-[10px] font-semibold text-[#C6A15B]">
                        {item.book.category}
                      </span>
                      <span className="text-[11px] text-[#E9E1D2]/50 capitalize">
                        Status: {item.status.replace(/_/g, ' ')}
                      </span>
                    </div>

                    <h3 className="font-serif font-bold text-sm sm:text-base text-[#F7F3EA] truncate group-hover:text-[#C6A15B] transition-colors">
                      {item.book.title}
                    </h3>
                    <p className="text-xs text-[#E9E1D2]/70 truncate">
                      {item.book.author}
                    </p>

                    {item.notes && (
                      <p className="text-[11px] text-[#E9E1D2]/60 italic line-clamp-1">
                        &ldquo;{item.notes}&rdquo;
                      </p>
                    )}
                  </div>
                </div>

                {/* Progress Indicator */}
                <div className="w-full md:w-56 space-y-1.5 shrink-0">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-[#E9E1D2]/70">Progress</span>
                    <span className="font-semibold text-[#F7F3EA]">{percent}%</span>
                  </div>
                  <div className="w-full bg-[#10241F] h-2 rounded-full overflow-hidden p-0.5 border border-[#254d3e]/50">
                    <div
                      className="bg-linear-to-r from-[#2dd4bf] to-[#14b8a6] h-full rounded-full transition-all duration-300"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-[#E9E1D2]/50">
                    <span>
                      {item.currentPage} / {item.totalPages} pages
                    </span>
                    {item.rating && (
                      <span className="text-[#C6A15B] font-semibold flex items-center gap-0.5">
                        <Star className="w-3 h-3 fill-[#C6A15B]" /> {item.rating}
                      </span>
                    )}
                  </div>
                </div>

                {/* Status Switcher & Actions */}
                <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
                  <button
                    onClick={() => openEditModal(item)}
                    className="p-2 rounded-xl bg-[#10241F] border border-[#254d3e] text-[#E9E1D2] hover:text-[#C6A15B] transition-colors cursor-pointer"
                    title="Edit reading progress & notes"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  {/* Quick move dropdown/menu */}
                  <div className="relative">
                    <select
                      value={item.status}
                      onChange={(e) => handleQuickMove(item.book.id, e.target.value as ReadingStatus)}
                      className="py-1.5 px-2.5 bg-[#10241F] border border-[#254d3e] text-xs font-medium text-[#F7F3EA] rounded-xl outline-hidden focus:border-[#C6A15B] cursor-pointer"
                    >
                      <option value="want_to_read">Want to Read</option>
                      <option value="currently_reading">Currently Reading</option>
                      <option value="finished">Finished</option>
                    </select>
                  </div>

                  <button
                    onClick={() => removeFromLibrary(item.book.id)}
                    className="p-2 rounded-xl bg-[#10241F] border border-[#254d3e] text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
                    title="Remove from library"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="py-16 text-center rounded-2xl bg-[#173D30]/20 border border-[#254d3e] p-8 max-w-md mx-auto space-y-4">
          <div className="w-12 h-12 rounded-full bg-[#10241F] flex items-center justify-center mx-auto text-[#C6A15B]">
            <BookOpen className="w-6 h-6" />
          </div>
          <h3 className="font-serif text-lg font-bold text-[#F7F3EA]">
            No books found on this shelf
          </h3>
          <p className="text-xs text-[#E9E1D2]/70 leading-relaxed">
            {searchQuery
              ? 'Try modifying your search keywords.'
              : 'Add titles to your library to track pages, goals, and reflections.'}
          </p>
          <button
            onClick={() => setActivePage('discover')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs transition-colors cursor-pointer"
          >
            <span>Browse Catalog</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Edit Reading Progress Modal */}
      {editingBook && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-[#173D30] border border-[#254d3e] rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-5 animate-in zoom-in-95 duration-200">
            <div>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C6A15B]">
                Update Progress
              </span>
              <h3 className="font-serif text-xl font-bold text-[#F7F3EA] truncate">
                {editingBook.book.title}
              </h3>
              <p className="text-xs text-[#E9E1D2]/70">{editingBook.book.author}</p>
            </div>

            {/* Status Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#E9E1D2]/80 block">
                Reading Shelf
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'want_to_read', label: 'Want to Read' },
                  { id: 'currently_reading', label: 'Reading' },
                  { id: 'finished', label: 'Finished' },
                ].map((s) => (
                  <button
                    type="button"
                    key={s.id}
                    onClick={() => {
                      setEditStatus(s.id as ReadingStatus);
                      if (s.id === 'finished') setEditPage(editingBook.totalPages);
                      if (s.id === 'want_to_read') setEditPage(0);
                    }}
                    className={`py-2 px-1 text-xs font-semibold rounded-xl border text-center transition-all cursor-pointer ${
                      editStatus === s.id
                        ? 'bg-[#C6A15B] text-[#10241F] border-[#C6A15B]'
                        : 'bg-[#10241F] border-[#254d3e] text-[#E9E1D2]'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Page Progress Input */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-[#E9E1D2]/80">
                <span>Current Page</span>
                <span className="font-semibold text-[#F7F3EA]">
                  {editPage} / {editingBook.totalPages} pages ({calculateProgress(editPage, editingBook.totalPages)}%)
                </span>
              </div>
              <input
                type="range"
                min="0"
                max={editingBook.totalPages}
                value={editPage}
                onChange={(e) => setEditPage(parseInt(e.target.value, 10) || 0)}
                className="w-full h-2 bg-[#10241F] rounded-lg appearance-none cursor-pointer accent-[#C6A15B]"
              />
              <input
                type="number"
                min="0"
                max={editingBook.totalPages}
                value={editPage}
                onChange={(e) => setEditPage(parseInt(e.target.value, 10) || 0)}
                className="w-full px-4 py-2 bg-[#10241F] border border-[#254d3e] rounded-xl text-sm font-semibold text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
              />
            </div>

            {/* Notes */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-[#E9E1D2]/80 block">
                Personal Reflections / Notes
              </label>
              <textarea
                rows={3}
                value={editNotes}
                onChange={(e) => setEditNotes(e.target.value)}
                placeholder="Any takeaways or quotes..."
                className="w-full p-3 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
              />
            </div>

            {/* Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEditingBook(null)}
                className="px-4 py-2 rounded-xl bg-[#10241F] text-xs font-medium text-[#E9E1D2] hover:bg-[#0c1a16] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveEdit}
                className="px-5 py-2 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs cursor-pointer"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
