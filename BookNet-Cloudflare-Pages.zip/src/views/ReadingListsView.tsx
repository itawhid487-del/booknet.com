import React, { useState } from 'react';
import {
  Bookmark,
  Plus,
  Share2,
  Trash2,
  Sparkles,
  Coffee,
  Compass,
  BookOpen,
  FolderHeart,
  Globe,
  Lock,
  ChevronRight,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { INITIAL_BOOKS } from '../services/booksData';
import { BookCard } from '../components/BookCard';

export const ReadingListsView: React.FC = () => {
  const {
    readingLists,
    createReadingList,
    deleteReadingList,
    toggleBookInList,
    setSelectedBookId,
    setActivePage,
    showToast,
  } = useApp();

  const [isCreatingList, setIsCreatingList] = useState(false);
  const [newListTitle, setNewListTitle] = useState('');
  const [newListDesc, setNewListDesc] = useState('');
  const [newListIcon, setNewListIcon] = useState('Sparkles');
  const [activeListId, setActiveListId] = useState<string>(
    readingLists[0]?.id || ''
  );

  const selectedList = readingLists.find((l) => l.id === activeListId) || readingLists[0];

  // Resolve books for the selected list
  const listBooks = selectedList
    ? INITIAL_BOOKS.filter((b) => selectedList.bookIds.includes(b.id))
    : [];

  const handleCreateList = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newListTitle.trim()) {
      showToast('Please provide a title for your reading list');
      return;
    }
    createReadingList(newListTitle, newListDesc, newListIcon);
    setNewListTitle('');
    setNewListDesc('');
    setIsCreatingList(false);
  };

  const handleCopyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast('Reading list link copied to clipboard!');
    }
  };

  const getListIcon = (iconName: string) => {
    switch (iconName) {
      case 'Coffee':
        return <Coffee className="w-5 h-5 text-amber-400" />;
      case 'Compass':
        return <Compass className="w-5 h-5 text-cyan-400" />;
      case 'FolderHeart':
        return <FolderHeart className="w-5 h-5 text-rose-400" />;
      case 'Sparkles':
      default:
        return <Sparkles className="w-5 h-5 text-[#C6A15B]" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold text-[#F7F3EA] mb-1">
            Curated Reading Lists
          </h1>
          <p className="text-xs text-[#E9E1D2]/70">
            Organize themed collections, share recommendations, and discover curated anthologies.
          </p>
        </div>

        <button
          onClick={() => setIsCreatingList(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs transition-colors self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Reading List</span>
        </button>
      </div>

      {/* Grid of Reading Lists */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {readingLists.map((list) => {
          const isSelected = list.id === activeListId;
          return (
            <div
              key={list.id}
              onClick={() => setActiveListId(list.id)}
              className={`p-5 rounded-2xl border transition-all cursor-pointer relative flex flex-col justify-between ${
                isSelected
                  ? 'bg-[#173D30] border-[#C6A15B] shadow-lg ring-1 ring-[#C6A15B]/50'
                  : 'bg-[#173D30]/40 border-[#254d3e] hover:bg-[#173D30]/70'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 rounded-xl bg-[#10241F] border border-[#254d3e] flex items-center justify-center">
                    {getListIcon(list.coverIcon)}
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] text-[#E9E1D2]/60">
                    {list.isPublic ? (
                      <span className="flex items-center gap-1 text-emerald-400">
                        <Globe className="w-3 h-3" /> Public
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-[#E9E1D2]/50">
                        <Lock className="w-3 h-3" /> Private
                      </span>
                    )}
                  </div>
                </div>

                <h3 className="font-serif font-bold text-base text-[#F7F3EA] mb-1">
                  {list.title}
                </h3>
                <p className="text-xs text-[#E9E1D2]/70 leading-relaxed line-clamp-2">
                  {list.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#254d3e]/50 flex items-center justify-between text-xs text-[#E9E1D2]/60">
                <span>{list.bookIds.length} books</span>
                <span className="text-[#C6A15B] font-semibold flex items-center gap-1">
                  View Collection <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected List Detailed Header and Books */}
      {selectedList && (
        <div className="p-6 md:p-8 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#254d3e] pb-6">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-[#10241F] border border-[#C6A15B]/30 flex items-center justify-center shrink-0">
                {getListIcon(selectedList.coverIcon)}
              </div>
              <div>
                <h2 className="font-serif text-2xl font-bold text-[#F7F3EA]">
                  {selectedList.title}
                </h2>
                <p className="text-xs text-[#E9E1D2]/70 mt-1 max-w-xl">
                  {selectedList.description}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyLink}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#10241F] border border-[#254d3e] hover:border-[#C6A15B]/50 text-xs font-medium text-[#F7F3EA] transition-colors cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5 text-[#C6A15B]" />
                <span>Share List</span>
              </button>

              {readingLists.length > 1 && (
                <button
                  onClick={() => deleteReadingList(selectedList.id)}
                  className="p-2 rounded-xl bg-[#10241F] border border-[#254d3e] text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
                  title="Delete List"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Books in this collection */}
          <div>
            <h3 className="font-serif font-semibold text-sm text-[#F7F3EA] mb-4">
              Books in this collection ({listBooks.length})
            </h3>

            {listBooks.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {listBooks.map((book) => (
                  <div key={book.id} className="relative group">
                    <BookCard book={book} />
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleBookInList(selectedList.id, book.id);
                      }}
                      className="absolute top-2 left-2 px-2 py-1 bg-black/80 hover:bg-rose-900 rounded-md text-[10px] text-white opacity-0 group-hover:opacity-100 transition-opacity z-20 cursor-pointer"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-[#10241F]/40 border border-[#254d3e] rounded-2xl p-6">
                <Bookmark className="w-8 h-8 text-[#E9E1D2]/40 mx-auto mb-2" />
                <p className="text-xs text-[#E9E1D2]/70">No books added to this list yet.</p>
                <button
                  onClick={() => setActivePage('discover')}
                  className="mt-3 px-4 py-2 rounded-xl bg-[#C6A15B] text-[#10241F] font-semibold text-xs cursor-pointer"
                >
                  Find Books to Add
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Create Reading List Modal */}
      {isCreatingList && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-[#173D30] border border-[#254d3e] rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-5 animate-in zoom-in-95 duration-200">
            <div>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C6A15B]">
                Curate a Shelf
              </span>
              <h3 className="font-serif text-xl font-bold text-[#F7F3EA]">
                Create New Reading List
              </h3>
            </div>

            <form onSubmit={handleCreateList} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-medium text-[#E9E1D2]/80">List Title</label>
                <input
                  type="text"
                  placeholder="e.g. Best Philosophy for 2026"
                  value={newListTitle}
                  onChange={(e) => setNewListTitle(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-[#E9E1D2]/80">Description</label>
                <textarea
                  rows={3}
                  placeholder="What is this collection about?"
                  value={newListDesc}
                  onChange={(e) => setNewListDesc(e.target.value)}
                  className="w-full p-3 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-[#E9E1D2]/80">Theme Icon</label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'Sparkles', label: 'Magic', icon: Sparkles },
                    { id: 'Coffee', label: 'Cozy', icon: Coffee },
                    { id: 'Compass', label: 'Explore', icon: Compass },
                    { id: 'FolderHeart', label: 'Love', icon: FolderHeart },
                  ].map((ic) => (
                    <button
                      type="button"
                      key={ic.id}
                      onClick={() => setNewListIcon(ic.id)}
                      className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors ${
                        newListIcon === ic.id
                          ? 'bg-[#10241F] border-[#C6A15B] text-[#C6A15B]'
                          : 'bg-[#10241F]/50 border-[#254d3e] text-[#E9E1D2]/60'
                      }`}
                    >
                      <ic.icon className="w-4 h-4" />
                      <span className="text-[10px]">{ic.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsCreatingList(false)}
                  className="px-4 py-2 rounded-xl bg-[#10241F] text-xs font-medium text-[#E9E1D2]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#C6A15B] text-[#10241F] font-bold text-xs"
                >
                  Create List
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
