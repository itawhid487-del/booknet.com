import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  BookOpen,
  Loader2,
  Globe2,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { searchOpenLibrary } from '../services/openLibrary';
import { Book } from '../types/index';
import { BookCard } from '../components/BookCard';
import { GENRE_CATEGORIES } from '../services/booksData';

export const DiscoverView: React.FC = () => {
  const { searchQuery, setSearchQuery, selectedGenre, setSelectedGenre } = useApp();

  const [books, setBooks] = useState<Book[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [totalFound, setTotalFound] = useState(0);
  const [dataSource, setDataSource] = useState<'open_library' | 'local'>('local');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('rating_desc');
  const [page, setPage] = useState(1);

  // Perform search when query, genre, or page changes
  useEffect(() => {
    let isCancelled = false;
    const fetchBooks = async () => {
      setIsLoading(true);
      try {
        const result = await searchOpenLibrary(searchQuery, selectedGenre, page);
        if (!isCancelled) {
          setBooks(result.books);
          setTotalFound(result.total);
          setDataSource(result.source);
        }
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        if (!isCancelled) {
          setIsLoading(false);
        }
      }
    };

    const debounceTimer = setTimeout(fetchBooks, 300);
    return () => {
      isCancelled = true;
      clearTimeout(debounceTimer);
    };
  }, [searchQuery, selectedGenre, page]);

  // Apply language filter and client-side sorting
  const filteredAndSortedBooks = React.useMemo(() => {
    let list = [...books];

    // Language filter
    if (selectedLanguage !== 'all') {
      list = list.filter((b) => {
        if (!b.language) return true;
        return (
          b.language.toLowerCase() === selectedLanguage.toLowerCase() ||
          (selectedLanguage === 'en' && b.language.toLowerCase().startsWith('eng')) ||
          (selectedLanguage === 'bn' && (b.language.toLowerCase().startsWith('ben') || b.language.toLowerCase().startsWith('ban')))
        );
      });
    }

    // Sort
    switch (sortBy) {
      case 'rating_desc':
        list.sort((a, b) => b.rating - a.rating);
        break;
      case 'title_asc':
        list.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case 'title_desc':
        list.sort((a, b) => b.title.localeCompare(a.title));
        break;
      case 'author_asc':
        list.sort((a, b) => a.author.localeCompare(b.author));
        break;
      case 'year_desc':
        list.sort((a, b) => {
          const yearA = parseInt(a.publishedDate || '0', 10);
          const yearB = parseInt(b.publishedDate || '0', 10);
          return yearB - yearA;
        });
        break;
    }

    return list;
  }, [books, selectedLanguage, sortBy]);

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div>
        <h1 className="font-serif text-3xl font-bold text-[#F7F3EA] mb-2">
          Discover Books
        </h1>
        <p className="text-sm text-[#E9E1D2]/70 max-w-2xl">
          Search millions of titles across Open Library or explore our curated collections,
          filtered by genre, language, and community ratings.
        </p>
      </div>

      {/* Search & Filter Controls */}
      <div className="p-5 rounded-2xl bg-[#173D30]/60 border border-[#254d3e] space-y-4 shadow-lg">
        {/* Main Search Row */}
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#E9E1D2]/50" />
            <input
              type="text"
              placeholder="Search by title, author, or ISBN (e.g., Dune, Andy Weir, 9780525559474)..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setPage(1);
              }}
              className="w-full pl-11 pr-4 py-3 bg-[#10241F] border border-[#254d3e] hover:border-[#C6A15B]/40 focus:border-[#C6A15B] rounded-xl text-sm text-[#F7F3EA] placeholder-[#E9E1D2]/40 outline-hidden transition-all shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#E9E1D2]/60 hover:text-[#F7F3EA]"
              >
                Clear
              </button>
            )}
          </div>

          {/* Language selector */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <Globe2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#E9E1D2]/50 pointer-events-none" />
              <select
                value={selectedLanguage}
                onChange={(e) => setSelectedLanguage(e.target.value)}
                className="pl-9 pr-8 py-3 bg-[#10241F] border border-[#254d3e] text-xs font-medium text-[#F7F3EA] rounded-xl outline-hidden focus:border-[#C6A15B] cursor-pointer appearance-none"
              >
                <option value="all">All Languages</option>
                <option value="en">English (Default)</option>
                <option value="bn">Bangla (বাংলা)</option>
                <option value="es">Spanish</option>
                <option value="fr">French</option>
              </select>
            </div>

            {/* Sort selector */}
            <div className="relative">
              <ArrowUpDown className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#E9E1D2]/50 pointer-events-none" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="pl-9 pr-8 py-3 bg-[#10241F] border border-[#254d3e] text-xs font-medium text-[#F7F3EA] rounded-xl outline-hidden focus:border-[#C6A15B] cursor-pointer appearance-none"
              >
                <option value="rating_desc">Highest Rated</option>
                <option value="title_asc">Title (A - Z)</option>
                <option value="title_desc">Title (Z - A)</option>
                <option value="author_asc">Author Name</option>
                <option value="year_desc">Latest Published</option>
              </select>
            </div>
          </div>
        </div>

        {/* Genre Pill Filter Carousel */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          <Filter className="w-4 h-4 text-[#C6A15B] shrink-0 mr-1" />
          {GENRE_CATEGORIES.map((cat) => {
            const isSelected = selectedGenre === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedGenre(cat.id);
                  setPage(1);
                }}
                className={`px-3.5 py-1.5 rounded-full text-xs font-medium shrink-0 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#C6A15B] text-[#10241F] font-bold shadow-xs'
                    : 'bg-[#10241F] text-[#E9E1D2]/80 hover:bg-[#10241F]/80 hover:text-[#F7F3EA] border border-[#254d3e]'
                }`}
              >
                {cat.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Results Header / Data Source badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-[#E9E1D2]/70">
        <div>
          <span>Showing </span>
          <strong className="text-[#F7F3EA] font-semibold">{filteredAndSortedBooks.length}</strong>
          <span> books </span>
          {searchQuery && (
            <span>
              matching &ldquo;<span className="text-[#C6A15B]">{searchQuery}</span>&rdquo;
            </span>
          )}
          {selectedGenre !== 'all' && (
            <span> in <span className="text-[#C6A15B] capitalize">{selectedGenre}</span></span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>
            Source:{' '}
            {dataSource === 'open_library'
              ? 'Open Library API (Verified)'
              : 'BookNet Editorial Catalog'}
          </span>
        </div>
      </div>

      {/* Book Grid / Loading State / Empty State */}
      {isLoading ? (
        <div className="py-20 flex flex-col items-center justify-center text-center space-y-3">
          <Loader2 className="w-8 h-8 text-[#C6A15B] animate-spin" />
          <p className="text-sm font-medium text-[#F7F3EA]">Searching library archives...</p>
          <p className="text-xs text-[#E9E1D2]/60">Connecting to Open Library database</p>
        </div>
      ) : filteredAndSortedBooks.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {filteredAndSortedBooks.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      ) : (
        <div className="py-16 text-center rounded-2xl bg-[#173D30]/30 border border-[#254d3e] p-8 max-w-lg mx-auto space-y-4">
          <div className="w-12 h-12 rounded-full bg-[#10241F] flex items-center justify-center mx-auto text-[#C6A15B]">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h3 className="font-serif text-lg font-bold text-[#F7F3EA]">No books matched your criteria</h3>
          <p className="text-xs text-[#E9E1D2]/70 leading-relaxed">
            Try searching with broader keywords, clearing the genre filter, or looking up a different title.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedGenre('all');
              setSelectedLanguage('all');
            }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#C6A15B] text-[#10241F] font-semibold text-xs hover:bg-[#d6b16b] cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Filters</span>
          </button>
        </div>
      )}
    </div>
  );
};
