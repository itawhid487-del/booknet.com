import React, { useState } from 'react';
import {
  Trophy,
  Flame,
  BookOpen,
  CheckCircle2,
  Bookmark,
  Calendar,
  Clock,
  Award,
  Layers,
  Compass,
  PenTool,
  Plus,
  Send,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  calculateReadingGoalStats,
  calculateWeeklyPages,
  checkAchievements,
  calculateProgress,
} from '../utils/library';

export const ProgressDashboardView: React.FC = () => {
  const {
    library,
    sessions,
    logReadingSession,
    currentUser,
    setSelectedBookId,
    setActivePage,
  } = useApp();

  const currentBooks = library.filter((b) => b.status === 'currently_reading');
  const finishedBooks = library.filter((b) => b.status === 'finished');
  const wantToReadBooks = library.filter((b) => b.status === 'want_to_read');

  // Stats calculation
  const goalStats = calculateReadingGoalStats(
    library,
    currentUser ? currentUser.readingGoal : 25
  );
  const weeklyData = calculateWeeklyPages(sessions);
  const achievements = checkAchievements(library, sessions);

  // Quick session logger state
  const [selectedBookForLog, setSelectedBookForLog] = useState<string>(
    currentBooks[0]?.book.id || library[0]?.book.id || ''
  );
  const [pagesToLog, setPagesToLog] = useState<number>(25);
  const [minutesSpent, setMinutesSpent] = useState<number>(30);
  const [sessionNote, setSessionNote] = useState<string>('');

  const maxWeeklyPage = Math.max(...weeklyData.map((d) => d.pages), 40);

  const handleLogSession = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBookForLog || pagesToLog <= 0) return;
    logReadingSession(selectedBookForLog, pagesToLog, minutesSpent, sessionNote);
    setSessionNote('');
  };

  const getAchievementIcon = (iconName: string) => {
    switch (iconName) {
      case 'BookOpen':
        return <BookOpen className="w-5 h-5" />;
      case 'Award':
        return <Award className="w-5 h-5" />;
      case 'Layers':
        return <Layers className="w-5 h-5" />;
      case 'Compass':
        return <Compass className="w-5 h-5" />;
      case 'PenTool':
      default:
        return <PenTool className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="font-serif text-3xl font-bold text-[#F7F3EA] mb-1">
          Reading Dashboard & Achievements
        </h1>
        <p className="text-xs text-[#E9E1D2]/70">
          Track your personal milestones, weekly pace, and reading streaks.
        </p>
      </div>

      {/* 4 Summary Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Books Finished */}
        <div className="p-5 rounded-2xl bg-[#173D30]/60 border border-[#254d3e] shadow-lg flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-purple-950/60 border border-purple-800/40 flex items-center justify-center text-purple-400 shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-medium text-[#E9E1D2]/60 uppercase tracking-wider block">
              Finished
            </span>
            <span className="font-serif text-2xl font-bold text-[#F7F3EA]">
              {finishedBooks.length}
            </span>
            <span className="text-[11px] text-emerald-400 block">titles completed</span>
          </div>
        </div>

        {/* Currently Reading */}
        <div className="p-5 rounded-2xl bg-[#173D30]/60 border border-[#254d3e] shadow-lg flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-sky-950/60 border border-sky-800/40 flex items-center justify-center text-sky-400 shrink-0">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-medium text-[#E9E1D2]/60 uppercase tracking-wider block">
              Reading Now
            </span>
            <span className="font-serif text-2xl font-bold text-[#F7F3EA]">
              {currentBooks.length}
            </span>
            <span className="text-[11px] text-sky-300 block">in active progress</span>
          </div>
        </div>

        {/* Want to Read */}
        <div className="p-5 rounded-2xl bg-[#173D30]/60 border border-[#254d3e] shadow-lg flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-950/60 border border-emerald-800/40 flex items-center justify-center text-emerald-400 shrink-0">
            <Bookmark className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-medium text-[#E9E1D2]/60 uppercase tracking-wider block">
              Want to Read
            </span>
            <span className="font-serif text-2xl font-bold text-[#F7F3EA]">
              {wantToReadBooks.length}
            </span>
            <span className="text-[11px] text-[#E9E1D2]/60 block">queued on shelf</span>
          </div>
        </div>

        {/* Total Pages Read */}
        <div className="p-5 rounded-2xl bg-[#173D30]/60 border border-[#254d3e] shadow-lg flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-950/60 border border-amber-800/40 flex items-center justify-center text-amber-400 shrink-0">
            <Flame className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-medium text-[#E9E1D2]/60 uppercase tracking-wider block">
              Annual Goal Pace
            </span>
            <span className="font-serif text-2xl font-bold text-[#F7F3EA]">
              {goalStats.percentage}%
            </span>
            <span className="text-[11px] text-[#C6A15B] block">
              {goalStats.aheadOrBehind >= 0
                ? `+${goalStats.aheadOrBehind} books ahead`
                : `${Math.abs(goalStats.aheadOrBehind)} books behind`}
            </span>
          </div>
        </div>
      </div>

      {/* Reading Goal Progress Card */}
      <div className="p-6 md:p-8 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C6A15B]">
              Annual Challenge
            </span>
            <h2 className="font-serif text-2xl font-bold text-[#F7F3EA]">
              2026 Reading Goal ({goalStats.finishedCount} / {goalStats.annualGoal} Books)
            </h2>
          </div>
          <span className="text-xs text-[#E9E1D2]/70">
            {goalStats.daysRemaining} days remaining this year
          </span>
        </div>

        {/* Large Progress Bar */}
        <div className="w-full bg-[#10241F] h-4 rounded-full overflow-hidden p-1 border border-[#254d3e]">
          <div
            className="bg-linear-to-r from-[#C6A15B] to-[#5eead4] h-full rounded-full transition-all duration-700"
            style={{ width: `${goalStats.percentage}%` }}
          />
        </div>

        <div className="flex flex-wrap items-center justify-between text-xs text-[#E9E1D2]/70 pt-1">
          <span>{goalStats.finishedCount} completed</span>
          <span className="text-[#C6A15B] font-semibold">
            {goalStats.annualGoal - goalStats.finishedCount} books to reach your dream
          </span>
          <span>Target: {goalStats.annualGoal} books</span>
        </div>
      </div>

      {/* Two Column Layout: Weekly Reading Chart & Quick Session Logger */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Weekly Reading Activity Chart */}
        <div className="lg:col-span-7 p-6 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-serif text-lg font-bold text-[#F7F3EA]">
                Weekly Reading Activity
              </h3>
              <p className="text-xs text-[#E9E1D2]/60">Pages completed each day</p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#C6A15B]">
              <Calendar className="w-4 h-4" />
              <span>Last 7 Days</span>
            </div>
          </div>

          {/* Bar Chart Visualization */}
          <div className="h-44 flex items-end justify-between gap-2 pt-6 px-2">
            {weeklyData.map((d, i) => {
              const heightPercent = Math.max(8, Math.round((d.pages / maxWeeklyPage) * 100));
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                  <span className="text-[10px] text-[#E9E1D2]/70 opacity-0 group-hover:opacity-100 transition-opacity">
                    {d.pages}p
                  </span>
                  <div className="w-full max-w-[36px] bg-[#10241F] rounded-t-lg overflow-hidden flex items-end p-0.5 border border-[#254d3e]">
                    <div
                      className="w-full bg-linear-to-t from-[#173D30] to-[#C6A15B] rounded-t-md transition-all duration-500 group-hover:brightness-125"
                      style={{ height: `${heightPercent}%` }}
                    />
                  </div>
                  <span className="text-xs font-semibold text-[#E9E1D2]/80">{d.day}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quick Log Today's Reading Session */}
        <div className="lg:col-span-5 p-6 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] shadow-xl space-y-4">
          <div>
            <h3 className="font-serif text-lg font-bold text-[#F7F3EA]">
              Log Reading Session
            </h3>
            <p className="text-xs text-[#E9E1D2]/60">
              Record pages read today to keep your streak alive!
            </p>
          </div>

          <form onSubmit={handleLogSession} className="space-y-3">
            <div>
              <label className="text-xs text-[#E9E1D2]/80 block mb-1">Select Title</label>
              <select
                value={selectedBookForLog}
                onChange={(e) => setSelectedBookForLog(e.target.value)}
                className="w-full p-2.5 bg-[#10241F] border border-[#254d3e] text-xs text-[#F7F3EA] rounded-xl outline-hidden focus:border-[#C6A15B]"
              >
                {library.map((b) => (
                  <option key={b.book.id} value={b.book.id}>
                    {b.book.title} ({b.currentPage}/{b.totalPages}p)
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-[#E9E1D2]/80 block mb-1">Pages Read</label>
                <input
                  type="number"
                  min="1"
                  max="1000"
                  value={pagesToLog}
                  onChange={(e) => setPagesToLog(parseInt(e.target.value, 10) || 1)}
                  className="w-full p-2 bg-[#10241F] border border-[#254d3e] text-xs text-[#F7F3EA] rounded-xl outline-hidden focus:border-[#C6A15B] text-center"
                />
              </div>
              <div>
                <label className="text-xs text-[#E9E1D2]/80 block mb-1">Time (Mins)</label>
                <input
                  type="number"
                  min="1"
                  max="400"
                  value={minutesSpent}
                  onChange={(e) => setMinutesSpent(parseInt(e.target.value, 10) || 1)}
                  className="w-full p-2 bg-[#10241F] border border-[#254d3e] text-xs text-[#F7F3EA] rounded-xl outline-hidden focus:border-[#C6A15B] text-center"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-[#E9E1D2]/80 block mb-1">
                Reflections (Optional)
              </label>
              <input
                type="text"
                placeholder="Key takeaway from today's reading..."
                value={sessionNote}
                onChange={(e) => setSessionNote(e.target.value)}
                className="w-full p-2 bg-[#10241F] border border-[#254d3e] text-xs text-[#F7F3EA] rounded-xl outline-hidden focus:border-[#C6A15B]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Log Reading Session</span>
            </button>
          </form>
        </div>
      </div>

      {/* Personal Achievements Section */}
      <div className="p-6 md:p-8 rounded-3xl bg-[#173D30]/60 border border-[#254d3e] shadow-xl space-y-6">
        <div>
          <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C6A15B]">
            Badges & Laurels
          </span>
          <h2 className="font-serif text-2xl font-bold text-[#F7F3EA]">
            Reader Achievements
          </h2>
          <p className="text-xs text-[#E9E1D2]/70">
            Earn distinct medals as you journey through stories, pages, and genres.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {achievements.map((ach) => (
            <div
              key={ach.id}
              className={`p-5 rounded-2xl border transition-all ${
                ach.unlocked
                  ? 'bg-[#10241F]/80 border-[#C6A15B]/60 shadow-md ring-1 ring-[#C6A15B]/30'
                  : 'bg-[#10241F]/30 border-[#254d3e]/50 opacity-60'
              }`}
            >
              <div className="flex items-center gap-3.5 mb-3">
                <div
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center border ${
                    ach.unlocked
                      ? 'bg-[#C6A15B]/20 text-[#C6A15B] border-[#C6A15B]'
                      : 'bg-[#173D30]/40 text-[#E9E1D2]/40 border-[#254d3e]'
                  }`}
                >
                  {getAchievementIcon(ach.icon)}
                </div>
                <div>
                  <h4 className="font-serif font-bold text-sm text-[#F7F3EA]">
                    {ach.title}
                  </h4>
                  <span className="text-[11px] text-[#C6A15B] font-medium">
                    {ach.unlocked ? 'Unlocked Laurel' : 'In Progress'}
                  </span>
                </div>
              </div>

              <p className="text-xs text-[#E9E1D2]/70 leading-relaxed mb-3">
                {ach.description}
              </p>

              {/* Progress Indicator */}
              <div className="space-y-1">
                <div className="w-full bg-[#10241F] h-1.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      ach.unlocked ? 'bg-[#C6A15B]' : 'bg-[#E9E1D2]/40'
                    }`}
                    style={{
                      width: `${Math.round((ach.progress / ach.maxProgress) * 100)}%`,
                    }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-[#E9E1D2]/50">
                  <span>Progress</span>
                  <span>
                    {ach.progress} / {ach.maxProgress}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
