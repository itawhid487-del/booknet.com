import React, { useState } from 'react';
import { LogIn, UserPlus, Mail, Lock, User, ArrowRight, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const SignInView: React.FC = () => {
  const { signIn, setActivePage } = useApp();
  const [email, setEmail] = useState('tawhid@example.com');
  const [password, setPassword] = useState('••••••••');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setError('Please provide a valid email address');
      return;
    }
    setError('');
    signIn(email);
  };

  return (
    <div className="py-12 flex items-center justify-center">
      <div className="max-w-md w-full p-8 rounded-3xl bg-[#173D30]/80 border border-[#254d3e] shadow-2xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-[#10241F] border border-[#C6A15B]/40 flex items-center justify-center text-[#C6A15B] mx-auto">
            <LogIn className="w-6 h-6" />
          </div>
          <h1 className="font-serif text-2xl font-bold text-[#F7F3EA]">
            Welcome back to BookNet
          </h1>
          <p className="text-xs text-[#E9E1D2]/70">
            Sign in to access your personal bookshelves and reading streak.
          </p>
        </div>

        {/* Demo Fast Login Buttons */}
        <div className="p-3 rounded-2xl bg-[#10241F]/60 border border-[#254d3e] text-xs space-y-2">
          <span className="text-[11px] text-[#C6A15B] font-semibold block">
            Quick Switch Demo Readers:
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => signIn('tawhid@example.com', 'Tawhid')}
              className="py-1.5 px-2 bg-[#173D30] hover:bg-[#173D30]/80 rounded-lg text-[#F7F3EA] text-center font-medium cursor-pointer"
            >
              Sign in as Tawhid
            </button>
            <button
              type="button"
              onClick={() => signIn('elena@example.com', 'Elena Rostova')}
              className="py-1.5 px-2 bg-[#173D30] hover:bg-[#173D30]/80 rounded-lg text-[#F7F3EA] text-center font-medium cursor-pointer"
            >
              Sign in as Elena
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs text-[#E9E1D2]/80">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#E9E1D2]/40" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full pl-10 pr-4 py-2.5 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-[#E9E1D2]/80">Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#E9E1D2]/40" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
              />
            </div>
          </div>

          {error && <p className="text-xs text-rose-400">{error}</p>}

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md"
          >
            <span>Sign In</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="text-center text-xs text-[#E9E1D2]/70 pt-2 border-t border-[#254d3e]">
          Don&apos;t have an account yet?{' '}
          <button
            onClick={() => setActivePage('signup')}
            className="text-[#C6A15B] font-semibold hover:underline cursor-pointer"
          >
            Create an Account
          </button>
        </div>
      </div>
    </div>
  );
};

export const SignUpView: React.FC = () => {
  const { signUp, setActivePage } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.includes('@') || !username.trim()) {
      setError('Please fill out all fields with valid information');
      return;
    }
    setError('');
    signUp(name, email, username);
  };

  return (
    <div className="py-12 flex items-center justify-center">
      <div className="max-w-md w-full p-8 rounded-3xl bg-[#173D30]/80 border border-[#254d3e] shadow-2xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-[#10241F] border border-[#C6A15B]/40 flex items-center justify-center text-[#C6A15B] mx-auto">
            <UserPlus className="w-6 h-6" />
          </div>
          <h1 className="font-serif text-2xl font-bold text-[#F7F3EA]">
            Join the BookNet Community
          </h1>
          <p className="text-xs text-[#E9E1D2]/70">
            Start discovering books, curating shelves, and sharing reading journeys.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs text-[#E9E1D2]/80">Full Name</label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#E9E1D2]/40" />
              <input
                type="text"
                placeholder="e.g. Jane Austen"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-[#E9E1D2]/80">Username</label>
            <input
              type="text"
              placeholder="e.g. bookish_wanderer"
              value={username}
              onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/\s+/g, '_'))}
              className="w-full px-4 py-2.5 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs text-[#E9E1D2]/80">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#E9E1D2]/40" />
              <input
                type="email"
                placeholder="reader@domain.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-[#E9E1D2]/80">Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#E9E1D2]/40" />
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-[#10241F] border border-[#254d3e] rounded-xl text-xs text-[#F7F3EA] outline-hidden focus:border-[#C6A15B]"
              />
            </div>
          </div>

          {error && <p className="text-xs text-rose-400">{error}</p>}

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-[#C6A15B] hover:bg-[#d6b16b] text-[#10241F] font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md"
          >
            <span>Create Free Account</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="text-center text-xs text-[#E9E1D2]/70 pt-2 border-t border-[#254d3e]">
          Already have an account?{' '}
          <button
            onClick={() => setActivePage('signin')}
            className="text-[#C6A15B] font-semibold hover:underline cursor-pointer"
          >
            Sign In
          </button>
        </div>
      </div>
    </div>
  );
};
