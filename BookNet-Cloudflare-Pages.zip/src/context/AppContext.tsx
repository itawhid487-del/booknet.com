import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Book,
  LibraryBook,
  ReadingList,
  Review,
  Discussion,
  Challenge,
  UserProfile,
  ReadingSession,
  ActivePage,
  ReadingStatus,
} from '../types/index';
import { INITIAL_BOOKS } from '../services/booksData';

interface AppContextType {
  activePage: ActivePage;
  setActivePage: (page: ActivePage) => void;
  selectedBookId: string | null;
  setSelectedBookId: (id: string | null) => void;
  selectedGenre: string;
  setSelectedGenre: (genre: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  
  // User state
  currentUser: UserProfile | null;
  signIn: (email: string, name?: string) => void;
  signUp: (name: string, email: string, username: string) => void;
  signOut: () => void;
  updateProfile: (updates: Partial<UserProfile>) => void;

  // Library
  library: LibraryBook[];
  addToLibrary: (book: Book, status?: ReadingStatus) => void;
  updateLibraryBook: (bookId: string, updates: Partial<LibraryBook>) => void;
  removeFromLibrary: (bookId: string) => void;
  getLibraryBook: (bookId: string) => LibraryBook | undefined;

  // Reading Lists
  readingLists: ReadingList[];
  createReadingList: (title: string, description: string, coverIcon?: string) => void;
  deleteReadingList: (id: string) => void;
  toggleBookInList: (listId: string, bookId: string) => void;

  // Sessions & Progress
  sessions: ReadingSession[];
  logReadingSession: (bookId: string, pagesRead: number, durationMinutes: number, notes?: string) => void;

  // Community & Reviews
  reviews: Review[];
  addReview: (review: Omit<Review, 'id' | 'createdAt' | 'helpfulCount' | 'helpfulUserIds'>) => void;
  editReview: (reviewId: string, content: string, rating: number, title: string) => void;
  deleteReview: (reviewId: string) => void;
  toggleHelpfulReview: (reviewId: string) => void;
  reportReview: (reviewId: string) => void;

  // Discussions
  discussions: Discussion[];
  addDiscussion: (title: string, content: string, category: Discussion['category']) => void;
  addReply: (discussionId: string, content: string) => void;
  likeDiscussion: (discussionId: string) => void;

  // Challenges
  challenges: Challenge[];
  toggleJoinChallenge: (challengeId: string) => void;

  // Notifications & UI toast
  notification: string | null;
  showToast: (msg: string) => void;
  clearNotification: () => void;

  // Reset & Backup
  resetToSampleData: () => void;
  exportDataJson: () => string;
  importDataJson: (json: string) => boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'booknet_state_v1';

const DEFAULT_USER: UserProfile = {
  id: 'usr_tawhid_01',
  name: 'Tawhid',
  username: 'tawhid_reads',
  email: 'tawhid@example.com',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
  bio: 'Lifelong learner, sci-fi enthusiast, and cozy coffee reader. Currently exploring speculative fiction and behavioral economics.',
  readingGoal: 25,
  favoriteGenres: ['Fiction', 'Sci-Fi', 'Fantasy', 'Self-Help'],
  joinedDate: 'January 2025',
};

const DEFAULT_LIBRARY: LibraryBook[] = [
  // Currently Reading (2)
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'the-midnight-library') || INITIAL_BOOKS[0],
    status: 'currently_reading',
    currentPage: 120,
    totalPages: 300,
    rating: 4.5,
    notes: 'Incredible thought experiment about alternate lives and regret. Chapter 14 really resonated.',
    startedAt: '2026-10-10',
    updatedAt: '2026-10-25T14:30:00Z',
  },
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'project-hail-mary') || INITIAL_BOOKS[1],
    status: 'currently_reading',
    currentPage: 180,
    totalPages: 496,
    notes: 'Rocky is an unforgettable character! Loving the hard science pacing.',
    startedAt: '2026-10-18',
    updatedAt: '2026-10-24T18:00:00Z',
  },
  // Finished (5)
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'atomic-habits') || INITIAL_BOOKS[4],
    status: 'finished',
    currentPage: 320,
    totalPages: 320,
    rating: 5,
    notes: 'Clear, actionable systems over goals.',
    startedAt: '2026-08-01',
    finishedAt: '2026-08-20',
    updatedAt: '2026-08-20T12:00:00Z',
  },
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'the-psychology-of-money') || INITIAL_BOOKS[3],
    status: 'finished',
    currentPage: 256,
    totalPages: 256,
    rating: 4.5,
    notes: 'Wealth is what you do not see. Essential perspective.',
    startedAt: '2026-09-01',
    finishedAt: '2026-09-14',
    updatedAt: '2026-09-14T09:00:00Z',
  },
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'dune') || INITIAL_BOOKS[2],
    status: 'finished',
    currentPage: 688,
    totalPages: 688,
    rating: 5,
    notes: 'A masterclass in worldbuilding and ecology.',
    startedAt: '2026-06-01',
    finishedAt: '2026-07-10',
    updatedAt: '2026-07-10T16:00:00Z',
  },
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'lessons-in-chemistry') || INITIAL_BOOKS[10],
    status: 'finished',
    currentPage: 400,
    totalPages: 400,
    rating: 4,
    notes: 'Witty, sharp, and moving.',
    startedAt: '2026-07-15',
    finishedAt: '2026-07-28',
    updatedAt: '2026-07-28T19:00:00Z',
  },
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'remarkably-bright-creatures') || INITIAL_BOOKS[11],
    status: 'finished',
    currentPage: 368,
    totalPages: 368,
    rating: 5,
    notes: 'Marcellus is the best narrator in contemporary fiction.',
    startedAt: '2026-08-25',
    finishedAt: '2026-09-08',
    updatedAt: '2026-09-08T11:00:00Z',
  },
  // Want to Read (8)
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'tomorrow-tomorrow-tomorrow') || INITIAL_BOOKS[6],
    status: 'want_to_read',
    currentPage: 0,
    totalPages: 416,
    updatedAt: '2026-09-15T10:00:00Z',
  },
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'demon-copperhead') || INITIAL_BOOKS[7],
    status: 'want_to_read',
    currentPage: 0,
    totalPages: 560,
    updatedAt: '2026-09-18T11:00:00Z',
  },
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'seven-husbands-of-evelyn-hugo') || INITIAL_BOOKS[8],
    status: 'want_to_read',
    currentPage: 0,
    totalPages: 400,
    updatedAt: '2026-09-20T12:00:00Z',
  },
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'fourth-wing') || INITIAL_BOOKS[9],
    status: 'want_to_read',
    currentPage: 0,
    totalPages: 528,
    updatedAt: '2026-09-22T13:00:00Z',
  },
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'it-ends-with-us') || INITIAL_BOOKS[5],
    status: 'want_to_read',
    currentPage: 0,
    totalPages: 384,
    updatedAt: '2026-09-25T14:00:00Z',
  },
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'pride-and-prejudice') || INITIAL_BOOKS[12],
    status: 'want_to_read',
    currentPage: 0,
    totalPages: 432,
    updatedAt: '2026-09-26T15:00:00Z',
  },
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'meditations') || INITIAL_BOOKS[13],
    status: 'want_to_read',
    currentPage: 0,
    totalPages: 254,
    updatedAt: '2026-09-28T16:00:00Z',
  },
  {
    book: INITIAL_BOOKS.find((b) => b.id === 'the-great-gatsby') || INITIAL_BOOKS[14],
    status: 'want_to_read',
    currentPage: 0,
    totalPages: 180,
    updatedAt: '2026-09-30T17:00:00Z',
  },
];

const DEFAULT_READING_LISTS: ReadingList[] = [
  {
    id: 'list-1',
    title: 'Mind-Expanding Speculative Fiction',
    description: 'Imaginative journeys exploring consciousness, humanity, and distant stars.',
    isPublic: true,
    coverIcon: 'Sparkles',
    bookIds: ['the-midnight-library', 'project-hail-mary', 'dune'],
    createdAt: '2026-09-01T00:00:00Z',
    updatedAt: '2026-10-15T00:00:00Z',
  },
  {
    id: 'list-2',
    title: 'Cozy Weekend Reads',
    description: 'Heartwarming, thoughtful books best enjoyed with a warm cup of Earl Grey.',
    isPublic: true,
    coverIcon: 'Coffee',
    bookIds: ['remarkably-bright-creatures', 'tomorrow-tomorrow-tomorrow', 'lessons-in-chemistry'],
    createdAt: '2026-09-10T00:00:00Z',
    updatedAt: '2026-10-18T00:00:00Z',
  },
  {
    id: 'list-3',
    title: 'Life Systems & Mastery',
    description: 'Practical philosophies and habit blueprints for continuous personal growth.',
    isPublic: false,
    coverIcon: 'Compass',
    bookIds: ['atomic-habits', 'the-psychology-of-money', 'meditations'],
    createdAt: '2026-09-12T00:00:00Z',
    updatedAt: '2026-10-20T00:00:00Z',
  },
];

const DEFAULT_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    bookId: 'the-midnight-library',
    bookTitle: 'The Midnight Library',
    bookCover: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=600',
    userId: 'usr_tawhid_01',
    userName: 'Tawhid',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
    rating: 5,
    title: 'A gentle reminder that every life has infinite possibility',
    content: 'This book arrived at the perfect time in my life. Nora Seed’s journey through the infinite shelves between life and death made me reflect deeply on what it means to live without paralysis from regret. Beautiful writing and deeply comforting.',
    helpfulCount: 42,
    helpfulUserIds: ['user_2', 'user_3'],
    createdAt: '2026-10-14T10:15:00Z',
  },
  {
    id: 'rev-2',
    bookId: 'project-hail-mary',
    bookTitle: 'Project Hail Mary',
    bookCover: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=600',
    userId: 'usr_sarah',
    userName: 'Sarah Jenkins',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
    rating: 5,
    title: 'Fist my bump! Best sci-fi of the decade',
    content: 'Andy Weir knocked it out of the park. The friendship between Ryland Grace and Rocky is wholesome, funny, and scientifically fascinating. I could not put it down.',
    helpfulCount: 88,
    createdAt: '2026-10-02T16:20:00Z',
  },
  {
    id: 'rev-3',
    bookId: 'atomic-habits',
    bookTitle: 'Atomic Habits',
    bookCover: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&q=80&w=600',
    userId: 'usr_marcus',
    userName: 'Marcus Aurelius Fan',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
    rating: 5,
    title: 'Focus on trajectory rather than current results',
    content: 'If you only read one productivity book this decade, make it this one. The concept of identity-based habits completely shifted how I approach reading every morning.',
    helpfulCount: 64,
    createdAt: '2026-09-20T11:00:00Z',
  },
  {
    id: 'rev-4',
    bookId: 'dune',
    bookTitle: 'Dune',
    bookCover: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&q=80&w=600',
    userId: 'usr_elena',
    userName: 'Elena Rostova',
    userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200',
    rating: 5,
    title: 'Unrivaled literary architecture',
    content: 'Herbert blends ecology, politics, and mysticism into a masterwork that feels as ancient as sand and as modern as tomorrow. Deserves every accolade.',
    helpfulCount: 51,
    createdAt: '2026-09-12T14:40:00Z',
  },
];

const DEFAULT_DISCUSSIONS: Discussion[] = [
  {
    id: 'disc-1',
    category: 'Book Club',
    title: 'The Midnight Library: Which alternate life spoke most to you?',
    content: 'In Chapter 22, Nora experiences her life as a glaciologist in Svalbard. Which version of Nora’s life felt the most compelling or emotional to you? Let’s discuss below!',
    authorName: 'Tawhid',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
    authorId: 'usr_tawhid_01',
    repliesCount: 4,
    likesCount: 19,
    likedByUser: true,
    createdAt: '2026-10-20T15:00:00Z',
    replies: [
      {
        id: 'rep-1',
        authorName: 'Clara Chen',
        authorAvatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=200',
        authorId: 'usr_clara',
        content: 'For me it was definitely the vineyard life with Ash. It showed that even a "perfect" quiet life still holds its own unforeseen griefs and nuances.',
        createdAt: '2026-10-21T09:30:00Z',
        likesCount: 8,
      },
      {
        id: 'rep-2',
        authorName: 'Julian Vance',
        authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
        authorId: 'usr_julian',
        content: 'The rock star life was heartbreaking because it highlighted how fame alienates the people you care about most.',
        createdAt: '2026-10-21T14:15:00Z',
        likesCount: 6,
      },
    ],
  },
  {
    id: 'disc-2',
    category: 'Recommendations',
    title: 'Looking for fast-paced sci-fi books like Project Hail Mary',
    content: 'I just finished Project Hail Mary and feel a massive reading slump approaching unless I find something equally witty, smart, and optimistic! Any suggestions?',
    authorName: 'Alex Mercer',
    authorAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=200',
    authorId: 'usr_alex',
    repliesCount: 6,
    likesCount: 24,
    createdAt: '2026-10-22T11:45:00Z',
    replies: [
      {
        id: 'rep-3',
        authorName: 'Tawhid',
        authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
        authorId: 'usr_tawhid_01',
        content: 'Check out "The Martian" (obviously!) and also "Children of Time" by Adrian Tchaikovsky and the "Murderbot Diaries" by Martha Wells!',
        createdAt: '2026-10-22T13:00:00Z',
        likesCount: 11,
      },
    ],
  },
  {
    id: 'disc-3',
    category: 'General Chat',
    title: 'Physical books, e-readers, or audiobooks: What is your ideal reading setup?',
    content: 'Do you prefer annotations in paperbacks, the portability of Kindle/Kobo, or listening on your daily walk? How has BookNet changed your tracking routine?',
    authorName: 'Maya Patel',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200',
    authorId: 'usr_maya',
    repliesCount: 8,
    likesCount: 31,
    createdAt: '2026-10-24T08:00:00Z',
    replies: [],
  },
];

const DEFAULT_CHALLENGES: Challenge[] = [
  {
    id: 'chal-2026',
    title: '2026 BookNet Annual Challenge',
    description: 'Read 25 books throughout the calendar year and earn the master reader laurel badge.',
    targetBooks: 25,
    currentCount: 5,
    participantCount: 4210,
    joined: true,
    endDate: 'December 31, 2026',
    badgeIcon: 'Award',
  },
  {
    id: 'chal-classics',
    title: 'Timeless Classics Voyage',
    description: 'Expand your literary foundation by reading 6 foundational world classics.',
    targetBooks: 6,
    currentCount: 1,
    participantCount: 1840,
    joined: false,
    endDate: 'June 30, 2026',
    badgeIcon: 'Landmark',
  },
  {
    id: 'chal-scifi',
    title: 'Cosmic Horizons Sci-Fi Quest',
    description: 'Explore distant galaxies and future concepts across 8 science fiction titles.',
    targetBooks: 8,
    currentCount: 2,
    participantCount: 2950,
    joined: true,
    endDate: 'October 31, 2026',
    badgeIcon: 'Compass',
  },
];

const DEFAULT_SESSIONS: ReadingSession[] = [
  { id: 's1', bookId: 'the-midnight-library', bookTitle: 'The Midnight Library', pagesRead: 35, durationMinutes: 45, date: '2026-10-25' },
  { id: 's2', bookId: 'the-midnight-library', bookTitle: 'The Midnight Library', pagesRead: 25, durationMinutes: 30, date: '2026-10-24' },
  { id: 's3', bookId: 'project-hail-mary', bookTitle: 'Project Hail Mary', pagesRead: 40, durationMinutes: 50, date: '2026-10-23' },
  { id: 's4', bookId: 'project-hail-mary', bookTitle: 'Project Hail Mary', pagesRead: 50, durationMinutes: 60, date: '2026-10-22' },
  { id: 's5', bookId: 'the-midnight-library', bookTitle: 'The Midnight Library', pagesRead: 30, durationMinutes: 40, date: '2026-10-21' },
  { id: 's6', bookId: 'the-midnight-library', bookTitle: 'The Midnight Library', pagesRead: 20, durationMinutes: 25, date: '2026-10-20' },
  { id: 's7', bookId: 'project-hail-mary', bookTitle: 'Project Hail Mary', pagesRead: 45, durationMinutes: 55, date: '2026-10-19' },
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activePage, setActivePage] = useState<ActivePage>('home');
  const [selectedBookId, setSelectedBookId] = useState<string | null>(null);
  const [selectedGenre, setSelectedGenre] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [notification, setNotification] = useState<string | null>(null);

  // Load from local storage or defaults
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_user`);
      return saved ? JSON.parse(saved) : DEFAULT_USER;
    } catch {
      return DEFAULT_USER;
    }
  });

  const [library, setLibrary] = useState<LibraryBook[]>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_library`);
      return saved ? JSON.parse(saved) : DEFAULT_LIBRARY;
    } catch {
      return DEFAULT_LIBRARY;
    }
  });

  const [readingLists, setReadingLists] = useState<ReadingList[]>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_lists`);
      return saved ? JSON.parse(saved) : DEFAULT_READING_LISTS;
    } catch {
      return DEFAULT_READING_LISTS;
    }
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_reviews`);
      return saved ? JSON.parse(saved) : DEFAULT_REVIEWS;
    } catch {
      return DEFAULT_REVIEWS;
    }
  });

  const [discussions, setDiscussions] = useState<Discussion[]>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_discussions`);
      return saved ? JSON.parse(saved) : DEFAULT_DISCUSSIONS;
    } catch {
      return DEFAULT_DISCUSSIONS;
    }
  });

  const [challenges, setChallenges] = useState<Challenge[]>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_challenges`);
      return saved ? JSON.parse(saved) : DEFAULT_CHALLENGES;
    } catch {
      return DEFAULT_CHALLENGES;
    }
  });

  const [sessions, setSessions] = useState<ReadingSession[]>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_sessions`);
      return saved ? JSON.parse(saved) : DEFAULT_SESSIONS;
    } catch {
      return DEFAULT_SESSIONS;
    }
  });

  // Persist to local storage
  useEffect(() => {
    try {
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_user`, JSON.stringify(currentUser));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_library`, JSON.stringify(library));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_lists`, JSON.stringify(readingLists));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_reviews`, JSON.stringify(reviews));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_discussions`, JSON.stringify(discussions));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_challenges`, JSON.stringify(challenges));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_sessions`, JSON.stringify(sessions));
    } catch (e) {
      console.warn('Failed to save to local storage', e);
    }
  }, [currentUser, library, readingLists, reviews, discussions, challenges, sessions]);

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification((curr) => (curr === msg ? null : curr));
    }, 4000);
  };

  const clearNotification = () => setNotification(null);

  // Authentication
  const signIn = (email: string, name?: string) => {
    const user: UserProfile = {
      id: `usr_${Date.now()}`,
      name: name || (email.split('@')[0] ? email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1) : 'Reader'),
      username: email.split('@')[0] || 'reader',
      email,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
      bio: 'Avid reader and explorer on BookNet.',
      readingGoal: 20,
      favoriteGenres: ['Fiction', 'Classics'],
      joinedDate: 'Just now',
    };
    setCurrentUser(user);
    showToast(`Welcome back, ${user.name}!`);
    setActivePage('home');
  };

  const signUp = (name: string, email: string, username: string) => {
    const user: UserProfile = {
      id: `usr_${Date.now()}`,
      name,
      username,
      email,
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
      bio: 'New BookNet member looking forward to reading journeys.',
      readingGoal: 20,
      favoriteGenres: ['Fiction'],
      joinedDate: 'Today',
    };
    setCurrentUser(user);
    showToast(`Account created successfully! Welcome to BookNet, ${name}.`);
    setActivePage('home');
  };

  const signOut = () => {
    setCurrentUser(null);
    showToast('Signed out of BookNet.');
  };

  const updateProfile = (updates: Partial<UserProfile>) => {
    if (!currentUser) return;
    setCurrentUser({ ...currentUser, ...updates });
    showToast('Profile updated successfully.');
  };

  // Library actions
  const addToLibrary = (book: Book, status: ReadingStatus = 'want_to_read') => {
    const exists = library.find((item) => item.book.id === book.id);
    if (exists) {
      updateLibraryBook(book.id, { status });
      showToast(`Updated "${book.title}" to ${status.replace(/_/g, ' ')}`);
      return;
    }

    const newEntry: LibraryBook = {
      book,
      status,
      currentPage: status === 'finished' ? book.pageCount : 0,
      totalPages: book.pageCount,
      startedAt: status === 'currently_reading' ? new Date().toISOString().split('T')[0] : undefined,
      finishedAt: status === 'finished' ? new Date().toISOString().split('T')[0] : undefined,
      updatedAt: new Date().toISOString(),
    };

    setLibrary((prev) => [newEntry, ...prev]);
    showToast(`Added "${book.title}" to your ${status.replace(/_/g, ' ')} list`);
  };

  const updateLibraryBook = (bookId: string, updates: Partial<LibraryBook>) => {
    setLibrary((prev) =>
      prev.map((item) => {
        if (item.book.id === bookId) {
          const now = new Date().toISOString();
          let startedAt = item.startedAt;
          let finishedAt = item.finishedAt;

          if (updates.status === 'currently_reading' && !startedAt) {
            startedAt = now.split('T')[0];
          }
          if (updates.status === 'finished') {
            finishedAt = now.split('T')[0];
            if (updates.currentPage === undefined) {
              updates.currentPage = item.totalPages;
            }
          }

          return {
            ...item,
            ...updates,
            startedAt: updates.startedAt !== undefined ? updates.startedAt : startedAt,
            finishedAt: updates.finishedAt !== undefined ? updates.finishedAt : finishedAt,
            updatedAt: now,
          };
        }
        return item;
      })
    );
  };

  const removeFromLibrary = (bookId: string) => {
    setLibrary((prev) => prev.filter((item) => item.book.id !== bookId));
    showToast('Book removed from your library');
  };

  const getLibraryBook = (bookId: string) => {
    return library.find((b) => b.book.id === bookId);
  };

  // Reading lists actions
  const createReadingList = (title: string, description: string, coverIcon: string = 'Book') => {
    const newList: ReadingList = {
      id: `list-${Date.now()}`,
      title,
      description,
      isPublic: true,
      coverIcon,
      bookIds: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setReadingLists((prev) => [newList, ...prev]);
    showToast(`Created reading list "${title}"`);
  };

  const deleteReadingList = (id: string) => {
    setReadingLists((prev) => prev.filter((l) => l.id !== id));
    showToast('Reading list deleted');
  };

  const toggleBookInList = (listId: string, bookId: string) => {
    setReadingLists((prev) =>
      prev.map((list) => {
        if (list.id === listId) {
          const hasBook = list.bookIds.includes(bookId);
          const newIds = hasBook
            ? list.bookIds.filter((id) => id !== bookId)
            : [...list.bookIds, bookId];
          showToast(hasBook ? `Removed book from list` : `Added book to list "${list.title}"`);
          return {
            ...list,
            bookIds: newIds,
            updatedAt: new Date().toISOString(),
          };
        }
        return list;
      })
    );
  };

  // Reading session log
  const logReadingSession = (bookId: string, pagesRead: number, durationMinutes: number, notes?: string) => {
    const bookItem = library.find((b) => b.book.id === bookId);
    const bookTitle = bookItem ? bookItem.book.title : 'Book';

    const newSession: ReadingSession = {
      id: `sess-${Date.now()}`,
      bookId,
      bookTitle,
      pagesRead,
      durationMinutes,
      date: new Date().toISOString().split('T')[0],
      notes,
    };

    setSessions((prev) => [newSession, ...prev]);

    // Also increment book current page if in library
    if (bookItem) {
      const newPage = Math.min(bookItem.totalPages, bookItem.currentPage + pagesRead);
      const isFinished = newPage >= bookItem.totalPages;
      updateLibraryBook(bookId, {
        currentPage: newPage,
        status: isFinished ? 'finished' : 'currently_reading',
      });
    }

    showToast(`Logged reading session: ${pagesRead} pages (${durationMinutes} mins)`);
  };

  // Reviews
  const addReview = (reviewData: Omit<Review, 'id' | 'createdAt' | 'helpfulCount' | 'helpfulUserIds'>) => {
    const newReview: Review = {
      ...reviewData,
      id: `rev-${Date.now()}`,
      helpfulCount: 0,
      createdAt: new Date().toISOString(),
    };
    setReviews((prev) => [newReview, ...prev]);

    // Also update rating on book in library if present
    if (getLibraryBook(reviewData.bookId)) {
      updateLibraryBook(reviewData.bookId, { rating: reviewData.rating });
    }

    showToast('Your review has been published!');
  };

  const editReview = (reviewId: string, content: string, rating: number, title: string) => {
    setReviews((prev) =>
      prev.map((rev) => (rev.id === reviewId ? { ...rev, content, rating, title } : rev))
    );
    showToast('Review updated.');
  };

  const deleteReview = (reviewId: string) => {
    setReviews((prev) => prev.filter((r) => r.id !== reviewId));
    showToast('Review deleted.');
  };

  const toggleHelpfulReview = (reviewId: string) => {
    const userId = currentUser ? currentUser.id : 'anon';
    setReviews((prev) =>
      prev.map((r) => {
        if (r.id === reviewId) {
          const helpfulUsers = r.helpfulUserIds || [];
          const isHelpful = helpfulUsers.includes(userId);
          const nextUsers = isHelpful
            ? helpfulUsers.filter((u) => u !== userId)
            : [...helpfulUsers, userId];
          return {
            ...r,
            helpfulCount: isHelpful ? Math.max(0, r.helpfulCount - 1) : r.helpfulCount + 1,
            helpfulUserIds: nextUsers,
          };
        }
        return r;
      })
    );
  };

  const reportReview = (reviewId: string) => {
    setReviews((prev) =>
      prev.map((r) => (r.id === reviewId ? { ...r, reported: true } : r))
    );
    showToast('Review reported for moderation review. Thank you for keeping BookNet safe.');
  };

  // Discussions
  const addDiscussion = (title: string, content: string, category: Discussion['category']) => {
    const newDisc: Discussion = {
      id: `disc-${Date.now()}`,
      category,
      title,
      content,
      authorName: currentUser ? currentUser.name : 'Book Lover',
      authorAvatar: currentUser ? currentUser.avatar : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
      authorId: currentUser ? currentUser.id : 'anon',
      repliesCount: 0,
      likesCount: 0,
      createdAt: new Date().toISOString(),
      replies: [],
    };
    setDiscussions((prev) => [newDisc, ...prev]);
    showToast('Discussion thread created!');
  };

  const addReply = (discussionId: string, content: string) => {
    const newReply = {
      id: `rep-${Date.now()}`,
      authorName: currentUser ? currentUser.name : 'Reader',
      authorAvatar: currentUser ? currentUser.avatar : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
      authorId: currentUser ? currentUser.id : 'anon',
      content,
      createdAt: new Date().toISOString(),
      likesCount: 0,
    };
    setDiscussions((prev) =>
      prev.map((d) => {
        if (d.id === discussionId) {
          return {
            ...d,
            repliesCount: d.repliesCount + 1,
            replies: [...d.replies, newReply],
          };
        }
        return d;
      })
    );
    showToast('Reply posted!');
  };

  const likeDiscussion = (discussionId: string) => {
    setDiscussions((prev) =>
      prev.map((d) => {
        if (d.id === discussionId) {
          const liked = !d.likedByUser;
          return {
            ...d,
            likedByUser: liked,
            likesCount: liked ? d.likesCount + 1 : Math.max(0, d.likesCount - 1),
          };
        }
        return d;
      })
    );
  };

  const toggleJoinChallenge = (challengeId: string) => {
    setChallenges((prev) =>
      prev.map((c) => {
        if (c.id === challengeId) {
          const joined = !c.joined;
          showToast(joined ? `Joined "${c.title}" challenge!` : `Left challenge.`);
          return {
            ...c,
            joined,
            participantCount: joined ? c.participantCount + 1 : c.participantCount - 1,
          };
        }
        return c;
      })
    );
  };

  // Reset & Backup
  const resetToSampleData = () => {
    setCurrentUser(DEFAULT_USER);
    setLibrary(DEFAULT_LIBRARY);
    setReadingLists(DEFAULT_READING_LISTS);
    setReviews(DEFAULT_REVIEWS);
    setDiscussions(DEFAULT_DISCUSSIONS);
    setChallenges(DEFAULT_CHALLENGES);
    setSessions(DEFAULT_SESSIONS);
    showToast('Sample data reset successfully.');
  };

  const exportDataJson = () => {
    return JSON.stringify(
      {
        currentUser,
        library,
        readingLists,
        reviews,
        discussions,
        challenges,
        sessions,
        exportedAt: new Date().toISOString(),
      },
      null,
      2
    );
  };

  const importDataJson = (json: string): boolean => {
    try {
      const parsed = JSON.parse(json);
      if (parsed.library) setLibrary(parsed.library);
      if (parsed.readingLists) setReadingLists(parsed.readingLists);
      if (parsed.reviews) setReviews(parsed.reviews);
      if (parsed.currentUser) setCurrentUser(parsed.currentUser);
      if (parsed.sessions) setSessions(parsed.sessions);
      showToast('Data imported successfully!');
      return true;
    } catch (e) {
      console.error(e);
      showToast('Failed to import data: Invalid JSON structure.');
      return false;
    }
  };

  return (
    <AppContext.Provider
      value={{
        activePage,
        setActivePage,
        selectedBookId,
        setSelectedBookId,
        selectedGenre,
        setSelectedGenre,
        searchQuery,
        setSearchQuery,
        currentUser,
        signIn,
        signUp,
        signOut,
        updateProfile,
        library,
        addToLibrary,
        updateLibraryBook,
        removeFromLibrary,
        getLibraryBook,
        readingLists,
        createReadingList,
        deleteReadingList,
        toggleBookInList,
        sessions,
        logReadingSession,
        reviews,
        addReview,
        editReview,
        deleteReview,
        toggleHelpfulReview,
        reportReview,
        discussions,
        addDiscussion,
        addReply,
        likeDiscussion,
        challenges,
        toggleJoinChallenge,
        notification,
        showToast,
        clearNotification,
        resetToSampleData,
        exportDataJson,
        importDataJson,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
