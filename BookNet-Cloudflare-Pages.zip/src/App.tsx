/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/Sidebar';
import { TopNavbar } from './components/TopNavbar';
import { RightSidebar } from './components/RightSidebar';
import { Footer } from './components/Footer';
import { Toast } from './components/Toast';

// Views
import { HomeView } from './views/HomeView';
import { DiscoverView } from './views/DiscoverView';
import { BookDetailView } from './views/BookDetailView';
import { LibraryView } from './views/LibraryView';
import { ReadingListsView } from './views/ReadingListsView';
import { ProgressDashboardView } from './views/ProgressDashboardView';
import { CommunityView } from './views/CommunityView';
import { ReviewsView } from './views/ReviewsView';
import { UserProfileView } from './views/UserProfileView';
import { SettingsView } from './views/SettingsView';
import { SignInView, SignUpView } from './views/AuthViews';
import {
  PrivacyPolicyView,
  TermsOfServiceView,
  ContactHelpView,
} from './views/StaticPages';

const MainContent: React.FC = () => {
  const { activePage } = useApp();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Scroll to top whenever the page changes
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [activePage]);

  // Determine if RightSidebar should be shown
  const showRightSidebar = ['home', 'discover'].includes(activePage);

  const renderActiveView = () => {
    switch (activePage) {
      case 'home':
        return <HomeView />;
      case 'discover':
        return <DiscoverView />;
      case 'book-detail':
        return <BookDetailView />;
      case 'library':
        return <LibraryView />;
      case 'lists':
        return <ReadingListsView />;
      case 'progress':
        return <ProgressDashboardView />;
      case 'community':
        return <CommunityView />;
      case 'reviews':
        return <ReviewsView />;
      case 'profile':
        return <UserProfileView />;
      case 'settings':
        return <SettingsView />;
      case 'signin':
        return <SignInView />;
      case 'signup':
        return <SignUpView />;
      case 'privacy':
        return <PrivacyPolicyView />;
      case 'terms':
        return <TermsOfServiceView />;
      case 'contact':
        return <ContactHelpView />;
      default:
        return <HomeView />;
    }
  };

  return (
    <div className="min-h-screen bg-[#10241F] text-[#F7F3EA] flex flex-row">
      {/* Left Navigation Sidebar */}
      <Sidebar
        isMobileOpen={isMobileMenuOpen}
        onCloseMobile={() => setIsMobileMenuOpen(false)}
      />

      {/* Main Column */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header Navbar */}
        <TopNavbar onOpenMobileMenu={() => setIsMobileMenuOpen(true)} />

        {/* Content Area with optional Right Sidebar */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 max-w-[1600px] w-full mx-auto">
          <div className="flex gap-8 items-start">
            {/* Center Dynamic Page Content */}
            <div className="flex-1 min-w-0">
              {renderActiveView()}
            </div>

            {/* Right Sidebar Widgets on Home/Discover */}
            {showRightSidebar && <RightSidebar />}
          </div>
        </main>

        {/* Global Footer */}
        <Footer />
      </div>

      {/* Floating Toast Notification */}
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
